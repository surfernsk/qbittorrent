<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pt_BR">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../gui/about.ui" line="15"/>
        <source>About qBittorrent</source>
        <translation>Sobre qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="56"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="89"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="121"/>
        <location filename="../gui/about.ui" line="212"/>
        <source>Nationality:</source>
        <translation>Nacionalidade:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="135"/>
        <location filename="../gui/about.ui" line="198"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="128"/>
        <location filename="../gui/about.ui" line="205"/>
        <source>E-mail:</source>
        <translation>E-mail:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="101"/>
        <source>Greece</source>
        <translation>Grécia</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="95"/>
        <source>Current maintainer</source>
        <translation>Atual mantenedor </translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="165"/>
        <source>Original author</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="249"/>
        <source>Special Thanks</source>
        <translation>Agradecimentos especiais</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="275"/>
        <source>Translators</source>
        <translation>Tradutores</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="327"/>
        <source>Libraries</source>
        <translation>Bibliotecas</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="333"/>
        <source>qBittorrent was built with the following libraries:</source>
        <translation>O qBittorrent foi construído com as seguintes bibliotecas:</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="171"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../gui/about.ui" line="301"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
</context>
<context>
    <name>AbstractWebApplication</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="416"/>
        <source>WebUI: Origin header &amp; Target origin mismatch!</source>
        <translation>Interface Web: Incompatibilidade entre o cabeçalho de origem &amp; origem do destino!</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="417"/>
        <source>Source IP: &apos;%1&apos;. Origin header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>IP de Origem: &apos;%1&apos;. Cabeçalho de origem: &apos;%2&apos;. Origem de destino: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="426"/>
        <source>WebUI: Referer header &amp; Target origin mismatch!</source>
        <translation>Interface Web: Incompatibilidade entre o cabeçalho do referente &amp; origem de destino!</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="427"/>
        <source>Source IP: &apos;%1&apos;. Referer header: &apos;%2&apos;. Target origin: &apos;%3&apos;</source>
        <translation>IP de Origem: &apos;%1&apos;. Cabeçalho do referente: &apos;%2&apos;. Origem de destino: &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="444"/>
        <source>WebUI: Invalid Host header, port mismatch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="445"/>
        <source>Request source IP: &apos;%1&apos;. Server port: &apos;%2&apos;. Received Host header: &apos;%3&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="476"/>
        <source>WebUI: Invalid Host header.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="477"/>
        <source>Request source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WebUI: Invalid Host header, port mismatch</source>
        <translation type="obsolete">Interface Web: Cabeçalho do host, incompatibilidade de porta</translation>
    </message>
    <message>
        <source>Source IP: &apos;%1&apos;. Received Host header: &apos;%2&apos;</source>
        <translation type="obsolete">IP de Origem: &apos;%1&apos;. Cabeçalho recebido do host: &apos;%2&apos;</translation>
    </message>
    <message>
        <source>WebUI: Invalid Host header</source>
        <translation type="obsolete">Interface Web: Cabeçalho inválido do host</translation>
    </message>
</context>
<context>
    <name>AddNewTorrentDialog</name>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="58"/>
        <source>Save at</source>
        <translation>Salvar em</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="67"/>
        <source>Set as default save path</source>
        <translation>Salvar como caminho padrão de salvamento</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="87"/>
        <source>Never show again</source>
        <translation>Não mostrar novamente</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="104"/>
        <source>Torrent settings</source>
        <translation>Configurações de torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="110"/>
        <source>Set as default category</source>
        <translation>Definir como categoria padrão</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="119"/>
        <source>Category:</source>
        <translation>Categoria:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="144"/>
        <source>Start torrent</source>
        <translation>Iniciar torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="190"/>
        <source>Torrent information</source>
        <translation>Informações do torrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="154"/>
        <source>Skip hash check</source>
        <translation>Pular checagem de hash</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="243"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="209"/>
        <source>Hash:</source>
        <translation>Hash:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="257"/>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="236"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="19"/>
        <source>Torrent Management Mode:</source>
        <translation>Modo de Gerenciamento de Torrents:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="26"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>O modo automático configura várias propriedades do torrent (ex: caminho para salvar) baseado na categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="30"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="35"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="77"/>
        <source>When checked, the .torrent file will not be deleted despite the settings at the &quot;Download&quot; page of the options dialog</source>
        <translation>Se marcado, o arquivo .torrent não será excluído apesar das configuraçãoes da página &quot;Download&quot; do diálogo de opções</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="80"/>
        <source>Do not delete .torrent file</source>
        <translation>Não excluir arquivo .torrrent</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="177"/>
        <source>Create subfolder</source>
        <translation>Criar subpasta</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="362"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="367"/>
        <source>High</source>
        <translation>Alto</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="372"/>
        <source>Maximum</source>
        <translation>Máximo</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.ui" line="377"/>
        <source>Do not download</source>
        <translation>Não baixar</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="274"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="280"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="702"/>
        <source>I/O Error</source>
        <translation>Erro de entrada e saída</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="288"/>
        <source>Invalid torrent</source>
        <translation>Torrent inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="493"/>
        <source>Renaming</source>
        <translation>Renomeando</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="498"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="523"/>
        <source>Rename error</source>
        <translation>Renomear erro</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="499"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>O nome está vazio ou contém caracteres proibidos. Por favor escolha um nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="728"/>
        <source>Not Available</source>
        <comment>This comment is unavailable</comment>
        <translation>Não Disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="729"/>
        <source>Not Available</source>
        <comment>This date is unavailable</comment>
        <translation>Não Disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="737"/>
        <source>Not available</source>
        <translation>Não disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="323"/>
        <source>Invalid magnet link</source>
        <translation>Link magnético inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="274"/>
        <source>The torrent file &apos;%1&apos; does not exist.</source>
        <translation>O arquivo torrent &apos;%1&apos; não existe.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="280"/>
        <source>The torrent file &apos;%1&apos; cannot be read from the disk. Probably you don&apos;t have enough permissions.</source>
        <translation>O arquivo torrent &apos;%1&apos; não pode ser lido a partir do disco. Provavelmente você não possui permissões suficientes.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="288"/>
        <source>Failed to load the torrent: %1.
Error: %2</source>
        <comment>Don&apos;t remove the &apos;
&apos; characters. They insert a newline.</comment>
        <translation>Falha ao carregar o torrent: %1
Erro: %2</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="300"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="305"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="334"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="339"/>
        <source>Already in the download list</source>
        <translation>Já está na lista de downloads</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="300"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="334"/>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers weren&apos;t merged because it is a private torrent.</source>
        <translation>O torrent &apos;%1&apos; já está na lista de downloads. O trackers não foram mesclados pois este é um torrent privado.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="305"/>
        <source>Torrent &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation>O torrent &apos;%1&apos; já está na lista de downloads. Os trackers foram mesclados.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="343"/>
        <source>Cannot add torrent</source>
        <translation>Não foi possível adicionar torrente</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="309"/>
        <source>Cannot add this torrent. Perhaps it is already in adding state.</source>
        <translation>Não foi possível adicionar este torrent. Talvez ele já esteja sendo adicionado.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="323"/>
        <source>This magnet link was not recognized</source>
        <translation>Este link magnético não foi reconhecido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="339"/>
        <source>Magnet link &apos;%1&apos; is already in the download list. Trackers were merged.</source>
        <translation>O link magnético &apos;%1&apos; já está na lista de downloads. Os trackers foram mesclados.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="343"/>
        <source>Cannot add this torrent. Perhaps it is already in adding.</source>
        <translation>Não foi possível adicionar este torrent. Talvez ele já esteja sendo adicionado.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="352"/>
        <source>Magnet link</source>
        <translation>Link magnético</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="358"/>
        <source>Retrieving metadata...</source>
        <translation>Capturando informações...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="443"/>
        <source>Not Available</source>
        <comment>This size is unavailable.</comment>
        <translation>Não Disponível</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="445"/>
        <source>Free space on disk: %1</source>
        <translation>Espaço livre no disco: %1</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="100"/>
        <source>Choose save path</source>
        <translation>Escolha o caminho de salvamento</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="493"/>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="524"/>
        <location filename="../gui/addnewtorrentdialog.cpp" line="562"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nome já está em uso nessa pasta. Por favor escolha um diferente.</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="561"/>
        <source>The folder could not be renamed</source>
        <translation>Esta pasta não pode ser renomeada</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="606"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="610"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="703"/>
        <source>Invalid metadata</source>
        <translation>Metadados inválido</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="710"/>
        <source>Parsing metadata...</source>
        <translation>Analisando metadados...</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="714"/>
        <source>Metadata retrieval complete</source>
        <translation>Captura de metadados completa</translation>
    </message>
    <message>
        <location filename="../gui/addnewtorrentdialog.cpp" line="768"/>
        <source>Download Error</source>
        <translation>Erro no download</translation>
    </message>
</context>
<context>
    <name>AdvancedSettings</name>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="234"/>
        <source> MiB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="345"/>
        <source>Outgoing ports (Min) [0: Disabled]</source>
        <translation>Portas de saída (Min) [0: Desabilitado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="350"/>
        <source>Outgoing ports (Max) [0: Disabled]</source>
        <translation>Portas de saída (Max) [0: Desabilitado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="360"/>
        <source>Recheck torrents on completion</source>
        <translation>Rechecar torrents quando concluir</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="366"/>
        <source>Transfer list refresh interval</source>
        <translation>Intervalo de atualização da lista de transferência</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="365"/>
        <source> ms</source>
        <comment> milliseconds</comment>
        <translation>ms</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="115"/>
        <source>Setting</source>
        <translation>Configuração</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="115"/>
        <source>Value</source>
        <comment>Value set for this setting</comment>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="230"/>
        <source> (disabled)</source>
        <translation>(desabilitado)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="232"/>
        <source> (auto)</source>
        <translation>(auto)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="245"/>
        <source>All addresses</source>
        <translation>Todos os endereços</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="282"/>
        <source>qBittorrent Section</source>
        <translation>Seção qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="284"/>
        <location filename="../gui/advancedsettings.cpp" line="289"/>
        <source>Open documentation</source>
        <translation>Abrir documentação</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="287"/>
        <source>libtorrent Section</source>
        <translation>Seção libtorrent</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="303"/>
        <source>Disk cache</source>
        <translation>Cache em disco</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="308"/>
        <source> s</source>
        <comment> seconds</comment>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="309"/>
        <source>Disk cache expiry interval</source>
        <translation>Intervalo de expiração de cache de disco </translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="312"/>
        <source>Enable OS cache</source>
        <translation>Ativar cache do sistema operacional</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="315"/>
        <source>Guided read cache</source>
        <translation>Cache de leitura guiado</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="318"/>
        <source>Send upload piece suggestions</source>
        <translation>Enviar sugestões de partes de upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="322"/>
        <location filename="../gui/advancedsettings.cpp" line="327"/>
        <source> KiB</source>
        <translation> KiB</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="324"/>
        <source>Send buffer watermark</source>
        <translation>Enviar marca d&apos;água do buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="329"/>
        <source>Send buffer low watermark</source>
        <translation>Enviar marca d&apos;água de buffer  baixo</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="334"/>
        <source>Send buffer watermark factor</source>
        <translation>Enviar fator de marca d&apos;água do buffer</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="339"/>
        <source> m</source>
        <comment> minutes</comment>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="357"/>
        <source>Allow multiple connections from the same IP address</source>
        <translation>Permitir múltiplas conexões a partir do mesmo endeeço IP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="369"/>
        <source>Resolve peer countries (GeoIP)</source>
        <translation>Determinar países dos pares (GeoIP)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="372"/>
        <source>Resolve peer host names</source>
        <translation>Determinar nomes dos pares</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="380"/>
        <source>Strict super seeding</source>
        <translation>Super semeador</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="405"/>
        <source>Network Interface (requires restart)</source>
        <translation>Interface de rede (requer reinício)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="408"/>
        <source>Optional IP Address to bind to (requires restart)</source>
        <translation>Endereço de IP opcional para ligar-se (necessário reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="411"/>
        <source>Listen on IPv6 address (requires restart)</source>
        <translation>Ouvir no endereço IPv6 (requer reinicialização)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="419"/>
        <source>Display notifications</source>
        <translation>Exibir notificações</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="422"/>
        <source>Display notifications for added torrents</source>
        <translation>Exibe notificações para torrents adicionados</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="425"/>
        <source>Download tracker&apos;s favicon</source>
        <translation>Baixar favicon do tracker</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="429"/>
        <source>Save path history length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="441"/>
        <source>Upload slots behavior</source>
        <translation>Comportamento dos slots de upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="445"/>
        <source>Upload choking algorithm</source>
        <translation>Algoritmo de bloqueio de upload</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="457"/>
        <source>Confirm torrent recheck</source>
        <translation>Confirmar re-checagem</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="461"/>
        <source>Confirm removal of all tags</source>
        <translation>Confirmar remoção de todas as tags</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="465"/>
        <source>Always announce to all trackers in a tier</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="469"/>
        <source>Always announce to all tiers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Always announce to all trackers</source>
        <translation type="obsolete">Sempre anunciar para todos os trackers</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="382"/>
        <source>Any interface</source>
        <comment>i.e. Any network interface</comment>
        <translation>Qualquer interface</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="340"/>
        <source>Save resume data interval</source>
        <comment>How often the fastresume file is saved.</comment>
        <translation>Gravar intervalo de dados de continuação</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="354"/>
        <source>%1-TCP mixed mode algorithm</source>
        <comment>uTP-TCP mixed mode algorithm</comment>
        <translation>Algoritmo de modo misto %1-TCP</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="377"/>
        <source>Maximum number of half-open connections [0: Unlimited]</source>
        <translation>Número máximo de conexões semiabertas [0: Ilimitado]</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="414"/>
        <source>IP Address to report to trackers (requires restart)</source>
        <translation>Endereço IP para reportar aos trackers (requer reinicio)</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="432"/>
        <source>Enable embedded tracker</source>
        <translation>Ativar tracker embutido</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="437"/>
        <source>Embedded tracker port</source>
        <translation>Porta do tracker embutido</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="449"/>
        <source>Check for software updates</source>
        <translation>Verificar atualizações</translation>
    </message>
    <message>
        <location filename="../gui/advancedsettings.cpp" line="453"/>
        <source>Use system icon theme</source>
        <translation>Usar tema de ícone do sistema</translation>
    </message>
</context>
<context>
    <name>Application</name>
    <message>
        <location filename="../app/application.cpp" line="146"/>
        <source>qBittorrent %1 started</source>
        <comment>qBittorrent v3.2.0alpha started</comment>
        <translation>qBittorrent %1 iniciado</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="287"/>
        <source>Torrent: %1, running external program, command: %2</source>
        <translation>Torrent: %1, executando programa externo, comando: %2</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="296"/>
        <source>Torrent: %1, run external program command too long (length &gt; %2), execution failed.</source>
        <translation>Torrent: %1, executar programa externo - comando muito longo (tamanho &gt; %2), falha na execução.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="320"/>
        <source>Torrent name: %1</source>
        <translation type="unfinished">Nome do torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="321"/>
        <source>Torrent size: %1</source>
        <translation type="unfinished">Tamanho do torrent: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="322"/>
        <source>Save path: %1</source>
        <translation type="unfinished">Caminho para salvar: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="323"/>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="unfinished">O torrent foi baixado em %1.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="325"/>
        <source>Thank you for using qBittorrent.</source>
        <translation type="unfinished">Obrigado por usar o qBittorrent.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="332"/>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation type="unfinished">[qBittorrent] %1 terminou de ser baixado</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="346"/>
        <source>Torrent: %1, sending mail notification</source>
        <translation>Torrent: %1, enviando notificação por e-mail</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="507"/>
        <source>Information</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="508"/>
        <source>To control qBittorrent, access the Web UI at http://localhost:%1</source>
        <translation>Para controlar o qBittorrent, acesse a Interface do Usuário na Web em http://localhost:%1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="509"/>
        <source>The Web UI administrator user name is: %1</source>
        <translation>O nome do administrador da Interface Web é: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="512"/>
        <source>The Web UI administrator password is still the default one: %1</source>
        <translation>A senha do administrador da Interface Web do usuário ainda é a padrão: %1</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="513"/>
        <source>This is a security risk, please consider changing your password from program preferences.</source>
        <translation>Este é um risco de segurança, por favor considere mudar a sua senha nas opções do programa.</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="675"/>
        <source>Saving torrent progress...</source>
        <translation>Salvando o progresso do torrent...</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="732"/>
        <source>Portable mode and explicit profile directory options are mutually exclusive</source>
        <translation>As opções de modo portátil e pasta de perfil explícito são mutuamente exclusivas</translation>
    </message>
    <message>
        <location filename="../app/application.cpp" line="735"/>
        <source>Portable mode implies relative fastresume</source>
        <translation>O modo portátil implica em resumo rápido relativo</translation>
    </message>
</context>
<context>
    <name>AutomatedRssDownloader</name>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="229"/>
        <source>Save to:</source>
        <translation>Salvar em:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="14"/>
        <source>RSS Downloader</source>
        <translation>Baixador RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="28"/>
        <source>Auto downloading of RSS torrents is disabled now! You can enable it in application settings.</source>
        <translation>O download automático de torrents RSS está desativado agora! Você pode ativá-lo nas configurações do programa.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="59"/>
        <source>Download Rules</source>
        <translation>Regras de Download</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="99"/>
        <source>Rule Definition</source>
        <translation>Definição da Regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="105"/>
        <source>Use Regular Expressions</source>
        <translation>Usar Expressões Regulares</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="114"/>
        <source>Must Contain:</source>
        <translation>Deve Conter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="121"/>
        <source>Must Not Contain:</source>
        <translation>Não Deve Conter:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="128"/>
        <source>Episode Filter:</source>
        <translation>Filtro de Episódio:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="201"/>
        <source>Assign Category:</source>
        <translation>Atribuir categoria:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="217"/>
        <source>Save to a Different Directory</source>
        <translation>Salvar em uma Pasta Diferente</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="257"/>
        <source>Ignore Subsequent Matches for (0 to Disable)</source>
        <comment>... X days</comment>
        <translation>Ignorar Resultados Subsequentes por (0 para Desabilitar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="267"/>
        <source>Disabled</source>
        <translation>Desativado</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="270"/>
        <source> days</source>
        <translation> dias</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="303"/>
        <source>Add Paused:</source>
        <translation>Adicionar pausado:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="311"/>
        <source>Use global settings</source>
        <translation>Usar configurações globais</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="316"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="321"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="342"/>
        <source>Apply Rule to Feeds:</source>
        <translation>Aplicar Regra aos Feeds:</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="364"/>
        <source>Matching RSS Articles</source>
        <translation>Artigos RSS Correspondentes</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="392"/>
        <source>&amp;Import...</source>
        <translation>&amp;Importar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.ui" line="402"/>
        <source>&amp;Export...</source>
        <translation>&amp;Exportar...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Matches articles based on episode filter.</source>
        <translation>Iguala artigos baseado no filtro de episódios.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="81"/>
        <source>Example: </source>
        <translation>Exemplo: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="82"/>
        <source> will match 2, 5, 8 through 15, 30 and onward episodes of season one</source>
        <comment>example X will match</comment>
        <translation> resultará nos episódios 2, 5, 8 a 15 e 30 em diante da temporada um</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Episode filter rules: </source>
        <translation>Regras do filtro de episódios: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="83"/>
        <source>Season number is a mandatory non-zero value</source>
        <translation>Número da temporada é um valor obrigatório diferente de zero</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="85"/>
        <source>Filter must end with semicolon</source>
        <translation>O filtro deve terminar com ponto e vírgula</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="86"/>
        <source>Three range types for episodes are supported: </source>
        <translation>Três tipos de intervalo para episódios são suportados: </translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="87"/>
        <source>Single number: &lt;b&gt;1x25;&lt;/b&gt; matches episode 25 of season one</source>
        <translation>Número único: &lt;b&gt;1x25;&lt;/b&gt; combina com o episódio 25 da temporada um</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="88"/>
        <source>Normal range: &lt;b&gt;1x25-40;&lt;/b&gt; matches episodes 25 through 40 of season one</source>
        <translation>Intervalo normal: &lt;b&gt;1x25-40;&lt;/b&gt; combina com os episódios 25 a 40 da temporada um</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="84"/>
        <source>Episode number is a mandatory positive value</source>
        <translation>O número do episódio é um valor positivo obrigatório</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="89"/>
        <source>Infinite range: &lt;b&gt;1x25-;&lt;/b&gt; matches episodes 25 and upward of season one, and all episodes of later seasons</source>
        <translation>Intervalo infinito: &lt;b&gt;1x25-;&lt;/b&gt; combina com os episódios 25 em diante da temporada um, e todos os episódios das temporadas posteriores</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="265"/>
        <source>Last Match: %1 days ago</source>
        <translation>Última Correspondência: %1 dias atrás</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="267"/>
        <source>Last Match: Unknown</source>
        <translation>Última Correspondência: Desconhecida</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="348"/>
        <source>New rule name</source>
        <translation>Nome da nova regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="348"/>
        <source>Please type the name of the new download rule.</source>
        <translation>Por favor digite o nome da nova regra de download.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="353"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="457"/>
        <source>Rule name conflict</source>
        <translation>Conflito no nome da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="354"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="458"/>
        <source>A rule with this name already exists, please choose another name.</source>
        <translation>Uma regra com o mesmo nome existe, por favor escolha outro.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="368"/>
        <source>Are you sure you want to remove the download rule named &apos;%1&apos;?</source>
        <translation>Quer mesmo remover a regra de download de nome %1?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="370"/>
        <source>Are you sure you want to remove the selected download rules?</source>
        <translation>Quer mesmo remover as regras de download selecionadas?</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="371"/>
        <source>Rule deletion confirmation</source>
        <translation>Confirmação de exclusão de regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="380"/>
        <source>Destination directory</source>
        <translation>Diretório de destino</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="417"/>
        <source>Add new rule...</source>
        <translation>Adicionar nova regra...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="423"/>
        <source>Delete rule</source>
        <translation>Deletar regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="425"/>
        <source>Rename rule...</source>
        <translation>Renomear regra...</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="428"/>
        <source>Delete selected rules</source>
        <translation>Deletar regras selecionadas</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="451"/>
        <source>Rule renaming</source>
        <translation>Renomeando regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="451"/>
        <source>Please type the new rule name</source>
        <translation>Por favor digite o novo nome da regra</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="568"/>
        <source>Regex mode: use Perl-compatible regular expressions</source>
        <translation>Modo Regex: usar expressões regulares compatíveis com Perl</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="610"/>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="648"/>
        <source>Position %1: %2</source>
        <translation>Posição %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="571"/>
        <source>Wildcard mode: you can use</source>
        <translation>Modo curinga: você pode usar</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="572"/>
        <source>? to match any single character</source>
        <translation>? para corresponder a qualquer caractere único</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="573"/>
        <source>* to match zero or more of any characters</source>
        <translation>* para corresponder a zero ou mais caracteres</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="574"/>
        <source>Whitespaces count as AND operators (all words, any order)</source>
        <translation>Espaços em branco contam como operadores AND (todas as palavras, qualquer ordem)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="575"/>
        <source>| is used as OR operator</source>
        <translation>| é usado como operador OR</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="576"/>
        <source>If word order is important use * instead of whitespace.</source>
        <translation>Se as ordem das palavras é importante, use * em vez de espaço em branco.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="583"/>
        <source>An expression with an empty %1 clause (e.g. %2)</source>
        <comment>We talk about regex/wildcards in the RSS filters section here. So a valid sentence would be: An expression with an empty | clause (e.g. expr|)</comment>
        <translation>Uma expressão com uma cláusula %1 vazia (ex. %2)</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="587"/>
        <source> will match all articles.</source>
        <translation> irá corresponder todos os artigos.</translation>
    </message>
    <message>
        <location filename="../gui/rss/automatedrssdownloader.cpp" line="588"/>
        <source> will exclude all articles.</source>
        <translation> irá excluir todos os artigos.</translation>
    </message>
</context>
<context>
    <name>BanListOptions</name>
    <message>
        <location filename="../gui/banlistoptions.ui" line="14"/>
        <source>List of banned IP addresses</source>
        <translation>Lista de endereços IP banidos</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.ui" line="77"/>
        <source>Ban IP</source>
        <translation>Banir IP</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.ui" line="84"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="81"/>
        <location filename="../gui/banlistoptions.cpp" line="91"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="81"/>
        <source>The entered IP address is invalid.</source>
        <translation>O endereço IP inserido é inválido.</translation>
    </message>
    <message>
        <location filename="../gui/banlistoptions.cpp" line="91"/>
        <source>The entered IP is already banned.</source>
        <translation>O endereço IP inserido já está banido.</translation>
    </message>
</context>
<context>
    <name>BitTorrent::Session</name>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="580"/>
        <source>Restart is required to toggle PeX support</source>
        <translation>É necessário reiniciar para alterar o suporte a PeX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1227"/>
        <source>Could not get GUID of configured network interface. Binding to IP %1</source>
        <translation>Não foi possível obter o GUID da interface de rede configurada.  Vinculando ao IP %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1726"/>
        <source>Embedded Tracker [ON]</source>
        <translation>Tracker embutido [LIGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1728"/>
        <source>Failed to start the embedded tracker!</source>
        <translation>Falha ao iniciar o tracker embutido!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1731"/>
        <source>Embedded Tracker [OFF]</source>
        <translation>Tracker embutido [DESLIGADO]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2389"/>
        <source>System network status changed to %1</source>
        <comment>e.g: System network status changed to ONLINE</comment>
        <translation>Estado de rede do sistema alterado para %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2389"/>
        <source>ONLINE</source>
        <translation>ONLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2389"/>
        <source>OFFLINE</source>
        <translation>OFFLINE</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2411"/>
        <source>Network configuration of %1 has changed, refreshing session binding</source>
        <comment>e.g: Network configuration of tun0 has changed, refreshing session binding</comment>
        <translation>A configuração de rede de %1 foi alterada, atualizando ligação da sessão</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2428"/>
        <source>Configured network interface address %1 isn&apos;t valid.</source>
        <comment>Configured network interface address 124.5.1568.1 isn&apos;t valid.</comment>
        <translation>O endereço %1 da interface de rede definida é inválida.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2767"/>
        <source>Encryption support [%1]</source>
        <translation>Suporte a criptografia [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2768"/>
        <source>FORCED</source>
        <translation>FORÇADO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2892"/>
        <source>%1 is not a valid IP address and was rejected while applying the list of banned addresses.</source>
        <translation>%1 não é um endereço IP válido e foi rejeitado ao aplicar a lista de endereços banidos.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3116"/>
        <source>Anonymous mode [%1]</source>
        <translation>Modo anônimo [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3542"/>
        <source>Unable to decode &apos;%1&apos; torrent file.</source>
        <translation>Impossível decodificar o arquivo torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3679"/>
        <source>Recursive download of file &apos;%1&apos; embedded in torrent &apos;%2&apos;</source>
        <comment>Recursive download of &apos;test.torrent&apos; embedded in torrent &apos;test2&apos;</comment>
        <translation>Download recursivo do arquivo &apos;%1&apos; embutido no torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3778"/>
        <source>Queue positions were corrected in %1 resume files</source>
        <translation>As posições na fila foram corrigidas em %1 arquivos de resumo</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4004"/>
        <source>Couldn&apos;t save &apos;%1.torrent&apos;</source>
        <translation>Não foi possível salvar &apos;%1.torrent&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4054"/>
        <source>&apos;%1&apos; was removed from the transfer list.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; foi removido da lista de transferências.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4067"/>
        <source>&apos;%1&apos; was removed from the transfer list and hard disk.</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; foi removido da lista de transferências e do disco rígido.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4079"/>
        <source>&apos;%1&apos; was removed from the transfer list but the files couldn&apos;t be deleted. Error: %2</source>
        <comment>&apos;xxx.avi&apos; was removed...</comment>
        <translation>&apos;%1&apos; foi removido da lista de transferências, mas os arquivos não foram excluídos. Erro: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4139"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because uTP is disabled.</comment>
        <translation>pois %1 está desabilitado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4142"/>
        <source>because %1 is disabled.</source>
        <comment>this peer was blocked because TCP is disabled.</comment>
        <translation>pois %1 está desabilitado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4160"/>
        <source>URL seed lookup failed for URL: &apos;%1&apos;, message: %2</source>
        <translation>Falha na procura de seeds falhou para url: &apos;%1&apos;, mensagem: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4206"/>
        <source>qBittorrent failed listening on interface %1 port: %2/%3. Reason: %4.</source>
        <comment>e.g: qBittorrent failed listening on interface 192.168.0.1 port: TCP/6881. Reason: already in use.</comment>
        <translation>O qBittorrent falhou ao escutar na porta da interface %1: %2/%3. Motivo: %4.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2058"/>
        <source>Downloading &apos;%1&apos;, please wait...</source>
        <comment>e.g: Downloading &apos;xxx.torrent&apos;, please wait...</comment>
        <translation>Baixando &apos;%1&apos;. Por favor, aguarde...</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1191"/>
        <location filename="../base/bittorrent/session.cpp" line="2505"/>
        <source>qBittorrent is trying to listen on any interface port: %1</source>
        <comment>e.g: qBittorrent is trying to listen on any interface port: TCP/6881</comment>
        <translation>qBittorrent está tentando escutar em qualquer porta de interface: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2447"/>
        <source>The network interface defined is invalid: %1</source>
        <translation>A interface de rede definida é inválida: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1204"/>
        <location filename="../base/bittorrent/session.cpp" line="2516"/>
        <source>qBittorrent is trying to listen on interface %1 port: %2</source>
        <comment>e.g: qBittorrent is trying to listen on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>O qBittorrent está tentando escutar na porta da interface %1: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <source>DHT support [%1]</source>
        <translation>Suporte a DHT [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="566"/>
        <location filename="../base/bittorrent/session.cpp" line="2768"/>
        <location filename="../base/bittorrent/session.cpp" line="3116"/>
        <source>ON</source>
        <translation>LIGADO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="551"/>
        <location filename="../base/bittorrent/session.cpp" line="566"/>
        <location filename="../base/bittorrent/session.cpp" line="2768"/>
        <location filename="../base/bittorrent/session.cpp" line="3116"/>
        <source>OFF</source>
        <translation>DESLIGADO</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="566"/>
        <source>Local Peer Discovery support [%1]</source>
        <translation>Suporte para Descoberta de Peer Local [%1]</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1776"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Removed.</source>
        <translation>&apos;%1&apos; alcançou a proporção máxima definida. Removido.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1781"/>
        <source>&apos;%1&apos; reached the maximum ratio you set. Paused.</source>
        <translation>&apos;%1&apos; alcançou a proporção máxima definida. Pausado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1800"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Removed.</source>
        <translation>&apos;%1&apos; alcançou o tempo máximo de semeadura definido. Removido.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="1805"/>
        <source>&apos;%1&apos; reached the maximum seeding time you set. Paused.</source>
        <translation>&apos;%1&apos; alcançou o tempo máximo de semeadura definido. Pausado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2481"/>
        <source>qBittorrent didn&apos;t find an %1 local address to listen on</source>
        <comment>qBittorrent didn&apos;t find an IPv4 local address to listen on</comment>
        <translation>O qBittorrent não encontrou um endereço local %1 no qual escutar</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="2509"/>
        <source>qBittorrent failed to listen on any interface port: %1. Reason: %2.</source>
        <comment>e.g: qBittorrent failed to listen on any interface port: TCP/6881. Reason: no such interface</comment>
        <translation>O qBittorrent não conseguiu escutar em qualquer porta de interface: %1. Motivo: %2.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3453"/>
        <source>Tracker &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>O tracker &apos;%1&apos; foi adicionado ao torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3463"/>
        <source>Tracker &apos;%1&apos; was deleted from torrent &apos;%2&apos;</source>
        <translation>O tracker &apos;%1&apos; foi excluído do torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3478"/>
        <source>URL seed &apos;%1&apos; was added to torrent &apos;%2&apos;</source>
        <translation>O seed da URL &apos;%1&apos; foi adicionado ao torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3484"/>
        <source>URL seed &apos;%1&apos; was removed from torrent &apos;%2&apos;</source>
        <translation>O seed da URL &apos;%1&apos; foi removido do torrent &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3727"/>
        <source>Unable to resume torrent &apos;%1&apos;.</source>
        <comment>e.g: Unable to resume torrent &apos;hash&apos;.</comment>
        <translation>Não foi possível resumir o torrent &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3812"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro de IP fornecido analisado com sucesso: %1 regras foram aplicadas.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3822"/>
        <source>Error: Failed to parse the provided IP filter.</source>
        <translation>Erro: Falha ao analisar o filtro de IP fornecido.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4038"/>
        <source>Couldn&apos;t add torrent. Reason: %1</source>
        <translation>Não foi possível adicionar o torrent. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="3987"/>
        <source>&apos;%1&apos; resumed. (fast resume)</source>
        <comment>&apos;torrent name&apos; was resumed. (fast resume)</comment>
        <translation>&apos;%1&apos; resumido. (resumir rápido)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4014"/>
        <source>&apos;%1&apos; added to download list.</source>
        <comment>&apos;torrent name&apos; was added to download list.</comment>
        <translation>&apos;%1&apos; adicionado à lista de downloads.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4103"/>
        <source>An I/O error occurred, &apos;%1&apos; paused. %2</source>
        <translation>Ocorreu um erro de E/S, &apos;%1&apos; pausado. %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4111"/>
        <source>UPnP/NAT-PMP: Port mapping failure, message: %1</source>
        <translation>UPnP/NAT-PMP: Falha no mapeamento de porta, mensagem: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4117"/>
        <source>UPnP/NAT-PMP: Port mapping successful, message: %1</source>
        <translation>UPnP/NAT-PMP: Mapeamento de porta bem sucedido, mensagem: %1</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4127"/>
        <source>due to IP filter.</source>
        <comment>this peer was blocked due to ip filter.</comment>
        <translation>devido ao filtro de IP.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4130"/>
        <source>due to port filter.</source>
        <comment>this peer was blocked due to port filter.</comment>
        <translation>devido ao filtro de porta.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4133"/>
        <source>due to i2p mixed mode restrictions.</source>
        <comment>this peer was blocked due to i2p mixed mode restrictions.</comment>
        <translation>devido às restrições de modo misto i2p.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4136"/>
        <source>because it has a low port.</source>
        <comment>this peer was blocked because it has a low port.</comment>
        <translation>pois ele tem uma porta baixa.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4180"/>
        <source>qBittorrent is successfully listening on interface %1 port: %2/%3</source>
        <comment>e.g: qBittorrent is successfully listening on interface 192.168.0.1 port: TCP/6881</comment>
        <translation>O qBittorrent está escutando com sucesso na porta da interface %1: %2/%3</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/session.cpp" line="4215"/>
        <source>External IP: %1</source>
        <comment>e.g. External IP: 192.168.0.1</comment>
        <translation>IP externo: %1</translation>
    </message>
</context>
<context>
    <name>BitTorrent::TorrentHandle</name>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1472"/>
        <source>Could not move torrent: &apos;%1&apos;. Reason: %2</source>
        <translation>Não foi possível mover torrent: &apos;%1&apos;. Motivo:%2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1650"/>
        <source>File sizes mismatch for torrent &apos;%1&apos;, pausing it.</source>
        <translation>O tamanho do arquivo para o torrent &apos;%1&apos; está incorreto. Pausando.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/torrenthandle.cpp" line="1656"/>
        <source>Fast resume data was rejected for torrent &apos;%1&apos;. Reason: %2. Checking again...</source>
        <translation>Resumo rápido rejeitado para o torrent &apos;%1&apos;. Motivo: %2. Verificando novamente...</translation>
    </message>
</context>
<context>
    <name>CategoryFilterModel</name>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="242"/>
        <source>Categories</source>
        <translation>Categorias</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="396"/>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <location filename="../gui/categoryfiltermodel.cpp" line="403"/>
        <source>Uncategorized</source>
        <translation>Sem categoria</translation>
    </message>
</context>
<context>
    <name>CategoryFilterWidget</name>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="115"/>
        <source>Add category...</source>
        <translation>Adicionar categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="123"/>
        <source>Add subcategory...</source>
        <translation>Adicionar subcategoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="129"/>
        <source>Edit category...</source>
        <translation>Editar categoria...</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="134"/>
        <source>Remove category</source>
        <translation>Remover categoria</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="140"/>
        <source>Remove unused categories</source>
        <translation>Remover categorias não utilizadas</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="147"/>
        <source>Resume torrents</source>
        <translation>Resumir torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="152"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/categoryfilterwidget.cpp" line="157"/>
        <source>Delete torrents</source>
        <translation>Excluir torrents</translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../gui/cookiesdialog.ui" line="14"/>
        <source>Manage Cookies</source>
        <translation>Gerenciar Cookies</translation>
    </message>
</context>
<context>
    <name>CookiesModel</name>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="49"/>
        <source>Domain</source>
        <translation>Domínio</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="51"/>
        <source>Path</source>
        <translation>Caminho</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="53"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="55"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../gui/cookiesmodel.cpp" line="57"/>
        <source>Expiration Date</source>
        <translation>Validade</translation>
    </message>
</context>
<context>
    <name>DeletionConfirmationDlg</name>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="49"/>
        <source>Are you sure you want to delete &apos;%1&apos; from the transfer list?</source>
        <comment>Are you sure you want to delete &apos;ubuntu-linux-iso&apos; from the transfer list?</comment>
        <translation>Tem certeza de que deseja deletar &apos;%1&apos; da lista de transferência?</translation>
    </message>
    <message>
        <location filename="../gui/deletionconfirmationdlg.h" line="51"/>
        <source>Are you sure you want to delete these %1 torrents from the transfer list?</source>
        <comment>Are you sure you want to delete these 5 torrents from the transfer list?</comment>
        <translation>Tem certeza que quer deletar estes %1 torrents da lista de transferências?</translation>
    </message>
</context>
<context>
    <name>DownloadedPiecesBar</name>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="177"/>
        <source>White: Missing pieces</source>
        <translation>Branco: Pedaços Faltando</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="178"/>
        <source>Green: Partial pieces</source>
        <translation>Verde: Pedaços parciais</translation>
    </message>
    <message>
        <location filename="../gui/properties/downloadedpiecesbar.cpp" line="179"/>
        <source>Blue: Completed pieces</source>
        <translation>Azul: Pedaços concluídos</translation>
    </message>
</context>
<context>
    <name>ExecutionLog</name>
    <message>
        <location filename="../gui/executionlog.ui" line="39"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.ui" line="45"/>
        <source>Blocked IPs</source>
        <translation>IPs bloqueados</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="108"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was blocked %2</source>
        <comment>x.y.z.w was blocked</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; foi bloqueado %2</translation>
    </message>
    <message>
        <location filename="../gui/executionlog.cpp" line="110"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; was banned</source>
        <comment>x.y.z.w was banned</comment>
        <translation>&lt;font color=&apos;red&apos;&gt;%1&lt;/font&gt; foi banido</translation>
    </message>
</context>
<context>
    <name>Feed</name>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="191"/>
        <source>Failed to download RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="201"/>
        <source>Failed to parse RSS feed at &apos;%1&apos;. Reason: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="228"/>
        <source>RSS feed at &apos;%1&apos; successfully updated. Added %2 new articles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="250"/>
        <source>Couldn&apos;t read RSS Session data from %1. Error: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="261"/>
        <source>Couldn&apos;t parse RSS Session data. Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="267"/>
        <source>Couldn&apos;t load RSS Session data. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base/rss/rss_feed.cpp" line="276"/>
        <source>Couldn&apos;t load RSS article &apos;%1#%2&apos;. Invalid data format.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FeedListWidget</name>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="49"/>
        <source>RSS feeds</source>
        <translation>RSS feeds</translation>
    </message>
    <message>
        <location filename="../gui/rss/feedlistwidget.cpp" line="61"/>
        <location filename="../gui/rss/feedlistwidget.cpp" line="115"/>
        <source>Unread  (%1)</source>
        <translation>Não lido (%1)</translation>
    </message>
</context>
<context>
    <name>FileLogger</name>
    <message>
        <location filename="../app/filelogger.cpp" line="168"/>
        <source>An error occured while trying to open the log file. Logging to file is disabled.</source>
        <translation>Ocorreu um erro ao tentar abrir o arquivo de log. O registro de log no arquivo está desativado.</translation>
    </message>
</context>
<context>
    <name>FileSystemPathEdit</name>
    <message>
        <location filename="../gui/fspathedit.cpp" line="55"/>
        <source>...</source>
        <comment>Launch file dialog button text (brief)</comment>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="57"/>
        <source>&amp;Browse...</source>
        <comment>Launch file dialog button text (full)</comment>
        <translation>&amp;Procurar...</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="59"/>
        <source>Choose a file</source>
        <comment>Caption for file open/save dialog</comment>
        <translation>Escolha um arquivo</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit.cpp" line="61"/>
        <source>Choose a folder</source>
        <comment>Caption for directory open dialog</comment>
        <translation>Escolha uma pasta</translation>
    </message>
</context>
<context>
    <name>FilterParserThread</name>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="127"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="261"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="408"/>
        <source>I/O Error: Could not open IP filter file in read mode.</source>
        <translation>Erro de E/S: Não foi possível abrir arquivo do filtro de IP no modo de leitura.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="205"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="322"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="330"/>
        <source>IP filter line %1 is malformed.</source>
        <translation>A linha %1 do filtro de IP está mal formada.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="213"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="338"/>
        <source>IP filter line %1 is malformed. Start IP of the range is malformed.</source>
        <translation>A linha %1 do filtro de IP está mal formada. O IP inicial do intervalo está mal formado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="221"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="346"/>
        <source>IP filter line %1 is malformed. End IP of the range is malformed.</source>
        <translation>A linha %1 do filtro de IP está mal formada. O IP final do intervalo está mal formado.</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="228"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="353"/>
        <source>IP filter line %1 is malformed. One IP is IPv4 and the other is IPv6!</source>
        <translation>A linha %1 do filtro de IP está mal formada. Um IP é IPv4 e o outro é IPv6!</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="241"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="365"/>
        <source>IP filter exception thrown for line %1. Exception is: %2</source>
        <translation>Exceção de filtro IP lançada para a linha %1. A exceção é: %2</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="419"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="431"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="452"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="461"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="471"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="481"/>
        <location filename="../base/bittorrent/private/filterparserthread.cpp" line="501"/>
        <source>Parsing Error: The filter file is not a valid PeerGuardian P2B file.</source>
        <translation>Erro de Análise: O arquivo de filtro não é um arquivo P2B válido do PeerGuardian.</translation>
    </message>
</context>
<context>
    <name>GeoIPDatabase</name>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="97"/>
        <location filename="../base/net/private/geoipdatabase.cpp" line="127"/>
        <source>Unsupported database file size.</source>
        <translation>Tamanho do arquivo de banco de dados não suportado.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="226"/>
        <source>Metadata error: &apos;%1&apos; entry not found.</source>
        <translation>Erro de metadados: Entrada &apos;%1&apos; não encontrada.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="227"/>
        <source>Metadata error: &apos;%1&apos; entry has invalid type.</source>
        <translation>Erro de metadados:r: Entrada &apos;%1&apos; tem um tipo inválido.</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="236"/>
        <source>Unsupported database version: %1.%2</source>
        <translation>Versão do banco de dados  não suportada: %1.%2</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="243"/>
        <source>Unsupported IP version: %1</source>
        <translation>Versão do IP não suportada: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="250"/>
        <source>Unsupported record size: %1</source>
        <translation>Tamanho de gravação não suportado: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="263"/>
        <source>Invalid database type: %1</source>
        <translation>Tipo do banco de dados inválido: %1</translation>
    </message>
    <message>
        <location filename="../base/net/private/geoipdatabase.cpp" line="284"/>
        <source>Database corrupted: no data section found.</source>
        <translation>Banco de dados corrompido: nenhuma seção de dados encontrada.</translation>
    </message>
</context>
<context>
    <name>HttpServer</name>
    <message>
        <location filename="../webui/extra_translations.h" line="37"/>
        <source>Exit qBittorrent</source>
        <translation>Sair do qBittorrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="39"/>
        <source>Only one link per line</source>
        <translation>Somente um link por linha</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="42"/>
        <source>Global upload rate limit must be greater than 0 or disabled.</source>
        <translation>A taxa limite de upload deve ser maior que 0 ou desabilitada.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="43"/>
        <source>Global download rate limit must be greater than 0 or disabled.</source>
        <translation>A taxa limite de download deve ser maior que 0 ou desabilitada.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="44"/>
        <source>Alternative upload rate limit must be greater than 0 or disabled.</source>
        <translation>A taxa limite de upload alternativa deve ser maior que 0 ou desabilitada.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="45"/>
        <source>Alternative download rate limit must be greater than 0 or disabled.</source>
        <translation>A taxa limite de download alternativa deve ser maior que 0 ou desabilitada.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="46"/>
        <source>Maximum active downloads must be greater than -1.</source>
        <translation>O máximo de downloads ativos deve ser maior do que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="47"/>
        <source>Maximum active uploads must be greater than -1.</source>
        <translation>O máximo de uploads ativos deve ser maior do que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="48"/>
        <source>Maximum active torrents must be greater than -1.</source>
        <translation>O máximo de torrents ativos deve ser maior do que -1.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="49"/>
        <source>Maximum number of connections limit must be greater than 0 or disabled.</source>
        <translation>O número máximo de conexões deve ser maior que 0 ou desabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="50"/>
        <source>Maximum number of connections per torrent limit must be greater than 0 or disabled.</source>
        <translation>O número máximo de conexões por torrent deve ser maior que 0 ou desabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="51"/>
        <source>Maximum number of upload slots per torrent limit must be greater than 0 or disabled.</source>
        <translation>O número máximo de slots de upload por torrent deve ser maior que 0 ou desabilitado.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="52"/>
        <source>Unable to save program preferences, qBittorrent is probably unreachable.</source>
        <translation>Impossível salvar preferências do programa, qBittorrent provavelmente está inatingível.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="72"/>
        <source>IRC: #qbittorrent on Freenode</source>
        <translation>IRC: #qbittorrent no Freenode</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="73"/>
        <source>Invalid category name:
Please do not use any special characters in the category name.</source>
        <translation>Nome de categoria inválido:
Por favor não use caracteres especiais no nome da categoria.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="74"/>
        <source>Unknown</source>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="75"/>
        <source>Hard Disk</source>
        <translation>Disco Rígido</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="76"/>
        <source>Share ratio limit must be between 0 and 9998.</source>
        <translation>O limite da proporção de compartilhamento deve ser de 0 a 9998.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="77"/>
        <source>Seeding time limit must be between 0 and 525600 minutes.</source>
        <translation>O limite do tempo de semeadura deve ser de 0 a 525600 minutos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="53"/>
        <source>The port used for incoming connections must be between 1 and 65535.</source>
        <translation>A porta usada para conexão de entrada deve estar entre 1 e 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="54"/>
        <source>The port used for the Web UI must be between 1 and 65535.</source>
        <translation>A porta usada para a Interface Web deve estar entre 1 e 65535.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="58"/>
        <source>Unable to log in, qBittorrent is probably unreachable.</source>
        <translation>Não é possível fazer login; qBittorrent provavelmente está inatingível.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="59"/>
        <source>Invalid Username or Password.</source>
        <translation>Nome de usuário ou senha inválidos.</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="60"/>
        <source>Username</source>
        <translation>Nome de usuário</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="61"/>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="62"/>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="63"/>
        <source>Original authors</source>
        <translation>Autores Originais</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="64"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="65"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="93"/>
        <source>Upload Torrents</source>
        <comment>Upload torrent files to qBittorent using WebUI</comment>
        <translation>Fazer upload de torrents</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="66"/>
        <source>Save files to location:</source>
        <translation>Salvar arquivos no diretório:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="67"/>
        <source>Cookie:</source>
        <translation>Cookie:</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="68"/>
        <source>Type folder here</source>
        <translation>Digite a pasta aqui</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="69"/>
        <source>More information</source>
        <translation>Mais informações&apos;</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="70"/>
        <source>Information about certificates</source>
        <translation>Informações sobre certificados</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="71"/>
        <source>Save Files to</source>
        <translation>Salvar Arquivos em</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="78"/>
        <source>Set location</source>
        <translation>Definir local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="79"/>
        <source>Limit upload rate</source>
        <translation>Taxa de limite de upload</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="80"/>
        <source>Limit download rate</source>
        <translation>Limite de taxa de download</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="81"/>
        <source>Rename torrent</source>
        <translation>Renomear torrent</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="85"/>
        <source>Other...</source>
        <comment>Save Files to: Watch Folder / Default Folder / Other...</comment>
        <translation>Outro...</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="86"/>
        <source>Monday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Segunda</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="87"/>
        <source>Tuesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Terça</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="88"/>
        <source>Wednesday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Quarta</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="89"/>
        <source>Thursday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Quinta</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="90"/>
        <source>Friday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sexta</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="91"/>
        <source>Saturday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Sábado</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="92"/>
        <source>Sunday</source>
        <comment>Schedule the use of alternative rate limits on ...</comment>
        <translation>Domingo</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="36"/>
        <source>Logout</source>
        <translation>Sair</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="38"/>
        <source>Download Torrents from their URLs or Magnet links</source>
        <translation>Baixar torrents a partir de suas URLs ou links magnéticos</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="40"/>
        <source>Upload local torrent</source>
        <translation>Fazer upload de torrent local</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="41"/>
        <source>Are you sure you want to delete the selected torrents from the transfer list?</source>
        <translation>Deseja realmente excluir os torrents selecionados da lista de transferência?</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="55"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="56"/>
        <source>qBittorrent client is not reachable</source>
        <translation>Cliente qBittorrent não está alcançável</translation>
    </message>
    <message>
        <location filename="../webui/extra_translations.h" line="57"/>
        <source>qBittorrent has been shutdown.</source>
        <translation>qBittorrent foi encerrado</translation>
    </message>
</context>
<context>
    <name>LogListWidget</name>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="48"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../gui/loglistwidget.cpp" line="49"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../gui/mainwindow.ui" line="43"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="68"/>
        <source>&amp;Tools</source>
        <translation>&amp;Ferramentas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="89"/>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="58"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="72"/>
        <source>On Downloads &amp;Done</source>
        <translation>Ao Concluir os &amp;Downloads</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="98"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="179"/>
        <source>&amp;Options...</source>
        <translation>&amp;Opções...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="189"/>
        <source>&amp;Resume</source>
        <translation>&amp;Resumir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="222"/>
        <source>Torrent &amp;Creator</source>
        <translation>&amp;Criar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="227"/>
        <source>Set Upload Limit...</source>
        <translation>Configurar Limite de Upload...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="232"/>
        <source>Set Download Limit...</source>
        <translation>Configurar Limite de Download...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="242"/>
        <source>Set Global Download Limit...</source>
        <translation>Configurar Limite Global de Download...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="247"/>
        <source>Set Global Upload Limit...</source>
        <translation>Configurar Limite Global de Upload...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="252"/>
        <source>Minimum Priority</source>
        <translation>Prioridade Mínima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="260"/>
        <source>Top Priority</source>
        <translation>Prioridade Máxima</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="268"/>
        <source>Decrease Priority</source>
        <translation>Diminuir Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="276"/>
        <source>Increase Priority</source>
        <translation>Aumentar Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="287"/>
        <location filename="../gui/mainwindow.ui" line="290"/>
        <source>Alternative Speed Limits</source>
        <translation>Limites de Velocidade Alternativos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="298"/>
        <source>&amp;Top Toolbar</source>
        <translation>Barra de &amp;Ferramentas Superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="301"/>
        <source>Display Top Toolbar</source>
        <translation>Exibir Barra de Ferramentas Superior</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="309"/>
        <source>Status &amp;Bar</source>
        <translation>&amp;Barra de Status</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="317"/>
        <source>S&amp;peed in Title Bar</source>
        <translation>&amp;Velocidade na Barra de Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="320"/>
        <source>Show Transfer Speed in Title Bar</source>
        <translation>Mostrar Velocidade de Transferência na Barra de Título</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="328"/>
        <source>&amp;RSS Reader</source>
        <translation>Leitor de &amp;RSS</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="336"/>
        <source>Search &amp;Engine</source>
        <translation>Mecanismo de &amp;Busca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="341"/>
        <source>L&amp;ock qBittorrent</source>
        <translation>Travar &amp;o qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="352"/>
        <source>Do&amp;nate!</source>
        <translation>&amp;Doar!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="199"/>
        <source>R&amp;esume All</source>
        <translation>R&amp;esume Todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="423"/>
        <source>Manage Cookies...</source>
        <translation>Gerenciar Cookies...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="426"/>
        <source>Manage stored network cookies</source>
        <translation>Gerencie cookies de rede armazenados</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="442"/>
        <source>Normal Messages</source>
        <translation>Mensagens Normais</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="450"/>
        <source>Information Messages</source>
        <translation>Mensagens Informativas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="458"/>
        <source>Warning Messages</source>
        <translation>Mensagens de Aviso</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="466"/>
        <source>Critical Messages</source>
        <translation>Mensagens Críticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="102"/>
        <source>&amp;Log</source>
        <translation>&amp;Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="363"/>
        <source>&amp;Exit qBittorrent</source>
        <translation>Sair do qBittorr&amp;ent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="371"/>
        <source>&amp;Suspend System</source>
        <translation>&amp;Suspender o Sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="379"/>
        <source>&amp;Hibernate System</source>
        <translation>&amp;Hibernar o Sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="387"/>
        <source>S&amp;hutdown System</source>
        <translation>Desli&amp;gar o Sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="395"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Não fazer nada</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="410"/>
        <source>&amp;Statistics</source>
        <translation>E&amp;statísticas</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="415"/>
        <source>Check for Updates</source>
        <translation>Verificar Atualizações</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="418"/>
        <source>Check for Program Updates</source>
        <translation>Verificar Atualizações do Programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="184"/>
        <source>&amp;About</source>
        <translation>&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="194"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="209"/>
        <source>&amp;Delete</source>
        <translation>&amp;Remover</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="204"/>
        <source>P&amp;ause All</source>
        <translation>P&amp;ausar Todos</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="166"/>
        <source>&amp;Add Torrent File...</source>
        <translation>&amp;Adicionar Arquivo Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="169"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="174"/>
        <source>E&amp;xit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="217"/>
        <source>Open URL</source>
        <translation>Abrir URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="237"/>
        <source>&amp;Documentation</source>
        <translation>&amp;Documentação</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="344"/>
        <source>Lock</source>
        <translation>Travar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="400"/>
        <location filename="../gui/mainwindow.ui" line="434"/>
        <location filename="../gui/mainwindow.cpp" line="1622"/>
        <source>Show</source>
        <translation>Mostrar</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1826"/>
        <source>Check for program updates</source>
        <translation>Verificar atualizações do programa</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="214"/>
        <source>Add Torrent &amp;Link...</source>
        <translation>Adicionar &amp;Link Torrent...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.ui" line="355"/>
        <source>If you like qBittorrent, please donate!</source>
        <translation>Se você curte qBittorrent, por favor faça sua doação!</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1860"/>
        <source>Execution Log</source>
        <translation>Execução Log</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <source>Clear the password</source>
        <translation>Limpar a senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="233"/>
        <source>Filter torrent list...</source>
        <translation>Filtrar lista de torrents...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="203"/>
        <source>&amp;Set Password</source>
        <translation>Definir &amp;Senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="171"/>
        <source>Preferences</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="205"/>
        <source>&amp;Clear Password</source>
        <translation>&amp;Limpar Senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="256"/>
        <source>Transfers</source>
        <translation>Transferências</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="452"/>
        <source>Torrent file association</source>
        <translation>Associação de arquivo torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="453"/>
        <source>qBittorrent is not the default application to open torrent files or Magnet links.
Do you want to associate qBittorrent to torrent files and Magnet links?</source>
        <translation>qBittorrent não é sua aplicação padrão para arquivos torrent e links magnéticos.
Gostaria de associar o qBittorrent para arquivos torrent e links magnéticos?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="536"/>
        <source>Icons Only</source>
        <translation>Apenas ícones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="538"/>
        <source>Text Only</source>
        <translation>Apenas texto</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="540"/>
        <source>Text Alongside Icons</source>
        <translation>Texto ao lado dos ícones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="542"/>
        <source>Text Under Icons</source>
        <translation>Texto embaixo dos ícones</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="544"/>
        <source>Follow System Style</source>
        <translation>Seguir estilo do sistema</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="631"/>
        <location filename="../gui/mainwindow.cpp" line="659"/>
        <location filename="../gui/mainwindow.cpp" line="1003"/>
        <source>UI lock password</source>
        <translation>Senha de travamento da UI</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="631"/>
        <location filename="../gui/mainwindow.cpp" line="659"/>
        <location filename="../gui/mainwindow.cpp" line="1003"/>
        <source>Please type the UI lock password:</source>
        <translation>Por favor digite sua senha UI:</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="635"/>
        <source>The password should contain at least 3 characters</source>
        <translation>A senha deve conter ao menos 3 caracteres</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="640"/>
        <source>Password update</source>
        <translation>Atualiza senha</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="640"/>
        <source>The UI lock password has been successfully updated</source>
        <translation>A senha de travamento da UI foi atualizada com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="647"/>
        <source>Are you sure you want to clear the password?</source>
        <translation>Tem certeza que você deseja limpar a senha?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="704"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="720"/>
        <source>Transfers (%1)</source>
        <translation>Transferências (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="816"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="816"/>
        <source>Failed to add torrent: %1</source>
        <translation>Falha ao adicionar o torrent: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="823"/>
        <source>Torrent added</source>
        <translation>Torrent adicionado</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="823"/>
        <source>&apos;%1&apos; was added.</source>
        <comment>e.g: xxx.avi was added.</comment>
        <translation>&apos;%1&apos; foi adicionado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="829"/>
        <source>Download completion</source>
        <translation>Completação de download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="835"/>
        <source>I/O Error</source>
        <comment>i.e: Input/Output Error</comment>
        <translation>Erro de I/O</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="920"/>
        <source>Recursive download confirmation</source>
        <translation>Confirmação de download recursivo</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="921"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="922"/>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="923"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="945"/>
        <source>Global Upload Speed Limit</source>
        <translation>Velocidade limite global de upload</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="960"/>
        <source>Global Download Speed Limit</source>
        <translation>Velocidade limite global de download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1026"/>
        <source>qBittorrent was just updated and needs to be restarted for the changes to be effective.</source>
        <translation>O qBittorrent foi atualizado e precisa ser reiniciado para que as mudanças sejam aplicadas.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1123"/>
        <source>Some files are currently transferring.</source>
        <translation>Alguns arquivos estão atualmente sendo transferidos.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1123"/>
        <source>Are you sure you want to quit qBittorrent?</source>
        <translation>Você tem certeza de que deseja fechar o qBittorrent?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1125"/>
        <source>&amp;No</source>
        <translation>&amp;Não</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1126"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sim</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1127"/>
        <source>&amp;Always Yes</source>
        <translation>Se&amp;mpre Sim</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1521"/>
        <source>%1/s</source>
        <comment>s is a shorthand for seconds</comment>
        <translation>%1/s</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1745"/>
        <source>Old Python Interpreter</source>
        <translation>Interpretador antigo do Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1745"/>
        <source>Your Python version (%1) is outdated. Please upgrade to latest version for search engines to work.
Minimum requirement: 2.7.9 / 3.3.0.</source>
        <translation>Sua versão (%1) do Python está desatualizada. Por favor, atualize para a última versão para a pesquisa funcionar.
Requisito mínimo: 2.7.9 / 3.3.0.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1810"/>
        <source>qBittorrent Update Available</source>
        <translation>Atualização disponível para o qBittorent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1811"/>
        <source>A new version is available.
Do you want to download %1?</source>
        <translation>Uma nova versão está disponível.
Deseja baixar o %1?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1820"/>
        <source>Already Using the Latest qBittorrent Version</source>
        <translation>Você está usando a versão mais recente. do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1755"/>
        <source>Undetermined Python version</source>
        <translation>Versão indeterminada do Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="829"/>
        <source>&apos;%1&apos; has finished downloading.</source>
        <comment>e.g: xxx.avi has finished downloading.</comment>
        <translation>&apos;%1&apos; terminou de ser baixado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="835"/>
        <source>An I/O error occurred for torrent &apos;%1&apos;.
 Reason: %2</source>
        <comment>e.g: An error occurred for torrent &apos;xxx.avi&apos;.
 Reason: disk is full.</comment>
        <translation>Ocorreu um erro de E/S no torrent &apos;%1&apos;.
Motivo: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="920"/>
        <source>The torrent &apos;%1&apos; contains torrent files, do you want to proceed with their download?</source>
        <translation>O torrent &apos;%1&apos; contém arquivos torrent. Deseja prosseguir com este download?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="935"/>
        <source>Couldn&apos;t download file at URL &apos;%1&apos;, reason: %2.</source>
        <translation>Não foi possível baixar arquivo na URL &apos;%1&apos;, motivo: %2.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1727"/>
        <source>Python found in %1: %2</source>
        <comment>Python found in PATH: /usr/local/bin:/usr/bin:/etc/bin</comment>
        <translation>Python encontrado em %1: %2</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1755"/>
        <source>Couldn&apos;t determine your Python version (%1). Search engine disabled.</source>
        <translation>Não foi possível determinar a sua versão do Python (%1). Pesquisa desativada.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1766"/>
        <location filename="../gui/mainwindow.cpp" line="1778"/>
        <source>Missing Python Interpreter</source>
        <translation>Faltando interpretador Python</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1767"/>
        <source>Python is required to use the search engine but it does not seem to be installed.
Do you want to install it now?</source>
        <translation>O Python é requerido para você poder usar a busca, mas ele parece não estar instalado.
Gostaria de instalar agora?</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1778"/>
        <source>Python is required to use the search engine but it does not seem to be installed.</source>
        <translation>O Python é requerido para usar a pesquisa, mas parece não estar instalado.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1821"/>
        <source>No updates available.
You are already using the latest version.</source>
        <translation>Nenhuma atualização disponível.
Você já está usando a versão mais recente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1825"/>
        <source>&amp;Check for Updates</source>
        <translation>&amp;Verificar Atualizações</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1984"/>
        <source>Checking for Updates...</source>
        <translation>Verificando Atualizações...</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1985"/>
        <source>Already checking for program updates in the background</source>
        <translation>Busca por atualizações do programa já está em execução em segundo plano</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2001"/>
        <source>Python found in &apos;%1&apos;</source>
        <translation>Python encontrado em &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2070"/>
        <source>Download error</source>
        <translation>Erro no download</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="2070"/>
        <source>Python setup could not be downloaded, reason: %1.
Please install it manually.</source>
        <translation>A instalação do Python não pôde ser baixada, razão: %1.
Por favor instale manualmente.</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="635"/>
        <location filename="../gui/mainwindow.cpp" line="1018"/>
        <source>Invalid password</source>
        <translation>Senha inválida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="672"/>
        <location filename="../gui/mainwindow.cpp" line="682"/>
        <source>RSS (%1)</source>
        <translation>RSS (%1)</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="935"/>
        <source>URL download error</source>
        <translation>Erro no download da URL</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1018"/>
        <source>The password is invalid</source>
        <translation>A senha está inválida</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1506"/>
        <location filename="../gui/mainwindow.cpp" line="1513"/>
        <source>DL speed: %1</source>
        <comment>e.g: Download speed: 10 KiB/s</comment>
        <translation>Velocidade de download: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1509"/>
        <location filename="../gui/mainwindow.cpp" line="1515"/>
        <source>UP speed: %1</source>
        <comment>e.g: Upload speed: 10 KiB/s</comment>
        <translation>Velocidade de upload: %1</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1528"/>
        <source>[D: %1, U: %2] qBittorrent %3</source>
        <comment>D = Download; U = Upload; %3 is qBittorrent version</comment>
        <translation>[D: %1, U: %2] qBittorrent %3</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1622"/>
        <source>Hide</source>
        <translation>Esconder</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1121"/>
        <source>Exiting qBittorrent</source>
        <translation>Saindo do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1319"/>
        <source>Open Torrent Files</source>
        <translation>Abrir Arquivos Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1320"/>
        <source>Torrent Files</source>
        <translation>Arquivos Torrent</translation>
    </message>
    <message>
        <location filename="../gui/mainwindow.cpp" line="1370"/>
        <source>Options were saved successfully.</source>
        <translation>Opções foram salvas com sucesso.</translation>
    </message>
</context>
<context>
    <name>Net::DNSUpdater</name>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="188"/>
        <source>Your dynamic DNS was successfully updated.</source>
        <translation>Seu DNS dinâmico foi atualizado com sucesso.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="193"/>
        <source>Dynamic DNS error: The service is temporarily unavailable, it will be retried in 30 minutes.</source>
        <translation>Erro de DNS dinâmico: O serviço está temporariamente inacessível, nova tentativa em 30 minutos.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="203"/>
        <source>Dynamic DNS error: hostname supplied does not exist under specified account.</source>
        <translation>Erro de DNS dinâmico: o hostname fornecido não existe na conta especificada.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="209"/>
        <source>Dynamic DNS error: Invalid username/password.</source>
        <translation>Erro de DNS dinâmico: Usuário/Senha inválido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="215"/>
        <source>Dynamic DNS error: qBittorrent was blacklisted by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erro de DNS dinâmico: O qBittorrent está na lista negra deste serviço. Por favor, envie este bug para http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="222"/>
        <source>Dynamic DNS error: %1 was returned by the service, please report a bug at http://bugs.qbittorrent.org.</source>
        <translation>Erro de DNS dinâmico: %1 foi retornado pelo serviço. Por favor, envie este bug para http://bugs.qbittorrent.org.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="229"/>
        <source>Dynamic DNS error: Your username was blocked due to abuse.</source>
        <translation>Erro de DNS dinâmico: Seu usuário foi bloqueado por motivo de abuso.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="249"/>
        <source>Dynamic DNS error: supplied domain name is invalid.</source>
        <translation>Erro de DNS dinâmico: O domínio é inválido.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="260"/>
        <source>Dynamic DNS error: supplied username is too short.</source>
        <translation>Erro de DNS dinâmico: Usuário informado é muito pequeno.</translation>
    </message>
    <message>
        <location filename="../base/net/dnsupdater.cpp" line="271"/>
        <source>Dynamic DNS error: supplied password is too short.</source>
        <translation>Erro de DNS dinâmico: A senha é muito pequena.</translation>
    </message>
</context>
<context>
    <name>Net::DownloadHandler</name>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="105"/>
        <source>I/O Error</source>
        <translation>Erro de E/S</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="118"/>
        <source>The file size is %1. It exceeds the download limit of %2.</source>
        <translation>O tamanho do arquivo é %1. Ele excede o limite de download em %2.</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="187"/>
        <source>Unexpected redirect to magnet URI.</source>
        <translation>Redirecionamento inesperado para URI magnético.</translation>
    </message>
</context>
<context>
    <name>Net::GeoIPManager</name>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="105"/>
        <location filename="../base/net/geoipmanager.cpp" line="434"/>
        <source>GeoIP database loaded. Type: %1. Build time: %2.</source>
        <translation>Banco de dados GeoIP carregado. Tipo: %1. Data de criação: %2.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="109"/>
        <location filename="../base/net/geoipmanager.cpp" line="455"/>
        <source>Couldn&apos;t load GeoIP database. Reason: %1</source>
        <translation>Não foi possível carregar o banco de dados GeoIP. Motivo: %1</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="381"/>
        <source>Venezuela, Bolivarian Republic of</source>
        <translation>Venezuela, República Bolivariana da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="384"/>
        <source>Viet Nam</source>
        <translation>Vietnã</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="394"/>
        <location filename="../base/net/geoipmanager.cpp" line="398"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="144"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="145"/>
        <source>United Arab Emirates</source>
        <translation>Emirados Árabes Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="146"/>
        <source>Afghanistan</source>
        <translation>Afeganistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="147"/>
        <source>Antigua and Barbuda</source>
        <translation>Antígua e Barbuda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="148"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="149"/>
        <source>Albania</source>
        <translation>Albânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="150"/>
        <source>Armenia</source>
        <translation>Armênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="151"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="152"/>
        <source>Antarctica</source>
        <translation>Antártica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="153"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="154"/>
        <source>American Samoa</source>
        <translation>Samoa Americana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="155"/>
        <source>Austria</source>
        <translation>Áustria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="156"/>
        <source>Australia</source>
        <translation>Austrália</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="157"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="159"/>
        <source>Azerbaijan</source>
        <translation>Azerbaidjão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="160"/>
        <source>Bosnia and Herzegovina</source>
        <translation>Bósnia-Herzegóvina</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="161"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="162"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="163"/>
        <source>Belgium</source>
        <translation>Bélgica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="164"/>
        <source>Burkina Faso</source>
        <translation>Burkina Fasso</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="165"/>
        <source>Bulgaria</source>
        <translation>Bulgária</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="166"/>
        <source>Bahrain</source>
        <translation>Barein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="167"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="168"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="170"/>
        <source>Bermuda</source>
        <translation>Bermudas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="171"/>
        <source>Brunei Darussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="174"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="175"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="176"/>
        <source>Bhutan</source>
        <translation>Butão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="177"/>
        <source>Bouvet Island</source>
        <translation>Ilha Bouvet</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="178"/>
        <source>Botswana</source>
        <translation>Botsuana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="179"/>
        <source>Belarus</source>
        <translation>Belarus</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="180"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="181"/>
        <source>Canada</source>
        <translation>Canadá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="182"/>
        <source>Cocos (Keeling) Islands</source>
        <translation>Ilhas Cocos (Keeling)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="183"/>
        <source>Congo, The Democratic Republic of the</source>
        <translation>Congo, República Democrática do</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="184"/>
        <source>Central African Republic</source>
        <translation>República Centro-Africana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="185"/>
        <source>Congo</source>
        <translation>Congo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="186"/>
        <source>Switzerland</source>
        <translation>Suíça</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="188"/>
        <source>Cook Islands</source>
        <translation>Ilhas Cook</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="189"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="190"/>
        <source>Cameroon</source>
        <translation>Camarões</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="191"/>
        <source>China</source>
        <translation>China</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="192"/>
        <source>Colombia</source>
        <translation>Colômbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="193"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="194"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="195"/>
        <source>Cape Verde</source>
        <translation>Cabo Verde</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="196"/>
        <source>Curacao</source>
        <translation>Curaçao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="197"/>
        <source>Christmas Island</source>
        <translation>Ilha Christmas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="198"/>
        <source>Cyprus</source>
        <translation>Chipre</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="199"/>
        <source>Czech Republic</source>
        <translation>República Tcheca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="200"/>
        <source>Germany</source>
        <translation>Alemanha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="201"/>
        <source>Djibouti</source>
        <translation>Djibuti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="202"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="203"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="204"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="205"/>
        <source>Algeria</source>
        <translation>Algéria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="206"/>
        <source>Ecuador</source>
        <translation>Equador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="207"/>
        <source>Estonia</source>
        <translation>Estônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="208"/>
        <source>Egypt</source>
        <translation>Egito</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="209"/>
        <source>Western Sahara</source>
        <translation>Saara Ocidental</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="210"/>
        <source>Eritrea</source>
        <translation>Eritréia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="211"/>
        <source>Spain</source>
        <translation>Espanha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="212"/>
        <source>Ethiopia</source>
        <translation>Etiópia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="213"/>
        <source>Finland</source>
        <translation>Finlândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="214"/>
        <source>Fiji</source>
        <translation>Fiji</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="215"/>
        <source>Falkland Islands (Malvinas)</source>
        <translation>Ilhas Falkland (Malvinas)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="216"/>
        <source>Micronesia, Federated States of</source>
        <translation>Micronésia, Estados Federados da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="217"/>
        <source>Faroe Islands</source>
        <translation>Ilhas Feroe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="218"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="219"/>
        <source>Gabon</source>
        <translation>Gabão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="220"/>
        <source>United Kingdom</source>
        <translation>Reino Unido</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="221"/>
        <source>Grenada</source>
        <translation>Granada</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="222"/>
        <source>Georgia</source>
        <translation>Geórgia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="223"/>
        <source>French Guiana</source>
        <translation>Guiana Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="225"/>
        <source>Ghana</source>
        <translation>Gana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="226"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="227"/>
        <source>Greenland</source>
        <translation>Groenlândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="228"/>
        <source>Gambia</source>
        <translation>Gâmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="229"/>
        <source>Guinea</source>
        <translation>Guiné</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="230"/>
        <source>Guadeloupe</source>
        <translation>Guadalupe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="231"/>
        <source>Equatorial Guinea</source>
        <translation>Guiné-Equatorial</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="232"/>
        <source>Greece</source>
        <translation>Grécia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="233"/>
        <source>South Georgia and the South Sandwich Islands</source>
        <translation>Ilhas Geórgia do Sul e Sandwich do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="234"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="235"/>
        <source>Guam</source>
        <translation>Guão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="236"/>
        <source>Guinea-Bissau</source>
        <translation>Guiné-Bissau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="237"/>
        <source>Guyana</source>
        <translation>Guiana</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="238"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="239"/>
        <source>Heard Island and McDonald Islands</source>
        <translation>Ilha Heard e Ilhas McDonald</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="240"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="241"/>
        <source>Croatia</source>
        <translation>Croácia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="242"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="243"/>
        <source>Hungary</source>
        <translation>Hungria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="244"/>
        <source>Indonesia</source>
        <translation>Indonésia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="245"/>
        <source>Ireland</source>
        <translation>Irlanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="246"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="248"/>
        <source>India</source>
        <translation>Índia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="249"/>
        <source>British Indian Ocean Territory</source>
        <translation>Território Britânico do Oceano Índico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="250"/>
        <source>Iraq</source>
        <translation>Iraque</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="251"/>
        <source>Iran, Islamic Republic of</source>
        <translation>Irã, República Islâmica do</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="252"/>
        <source>Iceland</source>
        <translation>Islândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="253"/>
        <source>Italy</source>
        <translation>Itália</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="255"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="256"/>
        <source>Jordan</source>
        <translation>Jordânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="257"/>
        <source>Japan</source>
        <translation>Japão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="258"/>
        <source>Kenya</source>
        <translation>Quênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="259"/>
        <source>Kyrgyzstan</source>
        <translation>Quirguistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="260"/>
        <source>Cambodia</source>
        <translation>Camboja</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="261"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="262"/>
        <source>Comoros</source>
        <translation>Comores</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="263"/>
        <source>Saint Kitts and Nevis</source>
        <translation>São Cristóvão e Nevis</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="264"/>
        <source>Korea, Democratic People&apos;s Republic of</source>
        <translation>Coréia do Norte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="265"/>
        <source>Korea, Republic of</source>
        <translation>Coréia do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="266"/>
        <source>Kuwait</source>
        <translation>Kuweit</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="267"/>
        <source>Cayman Islands</source>
        <translation>Ilhas Cayman</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="268"/>
        <source>Kazakhstan</source>
        <translation>Cazaquistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="269"/>
        <source>Lao People&apos;s Democratic Republic</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="270"/>
        <source>Lebanon</source>
        <translation>Líbano</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="271"/>
        <source>Saint Lucia</source>
        <translation>Santa Lúcia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="272"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="273"/>
        <source>Sri Lanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="274"/>
        <source>Liberia</source>
        <translation>Libéria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="275"/>
        <source>Lesotho</source>
        <translation>Lesoto</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="276"/>
        <source>Lithuania</source>
        <translation>Lituânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="277"/>
        <source>Luxembourg</source>
        <translation>Luxemburgo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="278"/>
        <source>Latvia</source>
        <translation>Letônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="280"/>
        <source>Morocco</source>
        <translation>Marrocos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="281"/>
        <source>Monaco</source>
        <translation>Mônaco</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="282"/>
        <source>Moldova, Republic of</source>
        <translation>Moldávia, República da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="285"/>
        <source>Madagascar</source>
        <translation>Madagáscar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="286"/>
        <source>Marshall Islands</source>
        <translation>Ilhas Marshall</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="288"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="289"/>
        <source>Myanmar</source>
        <translation>Mianmar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="290"/>
        <source>Mongolia</source>
        <translation>Mongólia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="292"/>
        <source>Northern Mariana Islands</source>
        <translation>Ilhas Marianas Setentrionais</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="293"/>
        <source>Martinique</source>
        <translation>Martinica</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="294"/>
        <source>Mauritania</source>
        <translation>Mauritânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="295"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="296"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="297"/>
        <source>Mauritius</source>
        <translation>Maurício</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="298"/>
        <source>Maldives</source>
        <translation>Maldivas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="299"/>
        <source>Malawi</source>
        <translation>Malauí</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="300"/>
        <source>Mexico</source>
        <translation>México</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="301"/>
        <source>Malaysia</source>
        <translation>Malásia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="302"/>
        <source>Mozambique</source>
        <translation>Moçambique</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="303"/>
        <source>Namibia</source>
        <translation>Namíbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="304"/>
        <source>New Caledonia</source>
        <translation>Nova Caledônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="305"/>
        <source>Niger</source>
        <translation>Níger</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="306"/>
        <source>Norfolk Island</source>
        <translation>Ilha Norfolk</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="307"/>
        <source>Nigeria</source>
        <translation>Nigéria</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="308"/>
        <source>Nicaragua</source>
        <translation>Nicarágua</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="309"/>
        <source>Netherlands</source>
        <translation>Holanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="310"/>
        <source>Norway</source>
        <translation>Noruega</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="311"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="312"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="313"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="314"/>
        <source>New Zealand</source>
        <translation>Nova Zelândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="315"/>
        <source>Oman</source>
        <translation>Omã</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="316"/>
        <source>Panama</source>
        <translation>Panamá</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="317"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="318"/>
        <source>French Polynesia</source>
        <translation>Polinésia Francesa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="319"/>
        <source>Papua New Guinea</source>
        <translation>Papua Nova Guiné</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="320"/>
        <source>Philippines</source>
        <translation>Filipinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="321"/>
        <source>Pakistan</source>
        <translation>Paquistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="322"/>
        <source>Poland</source>
        <translation>Polônia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="323"/>
        <source>Saint Pierre and Miquelon</source>
        <translation>São Pedro e Miquelão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="325"/>
        <source>Puerto Rico</source>
        <translation>Porto Rico</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="327"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="328"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="329"/>
        <source>Paraguay</source>
        <translation>Paraguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="330"/>
        <source>Qatar</source>
        <translation>Catar</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="331"/>
        <source>Reunion</source>
        <translation>Ilha Reunião</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="332"/>
        <source>Romania</source>
        <translation>Romênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="334"/>
        <source>Russian Federation</source>
        <translation>Federação Russa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="335"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="336"/>
        <source>Saudi Arabia</source>
        <translation>Arábia Saudita</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="337"/>
        <source>Solomon Islands</source>
        <translation>Ilhas Salomão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="338"/>
        <source>Seychelles</source>
        <translation>Seicheles</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="339"/>
        <source>Sudan</source>
        <translation>Sudão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="340"/>
        <source>Sweden</source>
        <translation>Suécia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="341"/>
        <source>Singapore</source>
        <translation>Singapura</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="343"/>
        <source>Slovenia</source>
        <translation>Eslovênia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="344"/>
        <source>Svalbard and Jan Mayen</source>
        <translation>Svalbard e Jan Mayen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="345"/>
        <source>Slovakia</source>
        <translation>Eslováquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="346"/>
        <source>Sierra Leone</source>
        <translation>Serra Leoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="347"/>
        <source>San Marino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="348"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="349"/>
        <source>Somalia</source>
        <translation>Somália</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="350"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="352"/>
        <source>Sao Tome and Principe</source>
        <translation>São Tomé e Príncipe</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="353"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="355"/>
        <source>Syrian Arab Republic</source>
        <translation>Síria, República Árabe da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="356"/>
        <source>Swaziland</source>
        <translation>Suazilândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="357"/>
        <source>Turks and Caicos Islands</source>
        <translation>Ilhas Turks e Caicos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="358"/>
        <source>Chad</source>
        <translation>Chade</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="359"/>
        <source>French Southern Territories</source>
        <translation>Terras Austrais e Antárticas Francesas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="360"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="361"/>
        <source>Thailand</source>
        <translation>Tailândia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="362"/>
        <source>Tajikistan</source>
        <translation>Tadjiquistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="363"/>
        <source>Tokelau</source>
        <translation>Toquelau</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="365"/>
        <source>Turkmenistan</source>
        <translation>Turcomenistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="366"/>
        <source>Tunisia</source>
        <translation>Tunísia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="367"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="423"/>
        <source>Could not decompress GeoIP database file.</source>
        <translation>Não foi possível descompactar o arquivo do banco de dados GeoIP.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="364"/>
        <source>Timor-Leste</source>
        <translation>Timor Leste</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="172"/>
        <source>Bolivia, Plurinational State of</source>
        <translation>Bolívia, Estado Plurinacional da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="173"/>
        <source>Bonaire, Sint Eustatius and Saba</source>
        <translation>Bonaire, Santo Eustáquio e Saba</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="187"/>
        <source>Cote d&apos;Ivoire</source>
        <translation>Cote d&apos;Ivoire</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="279"/>
        <source>Libya</source>
        <translation>Líbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="284"/>
        <source>Saint Martin (French part)</source>
        <translation>Saint Martin (parte francesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="287"/>
        <source>Macedonia, The Former Yugoslav Republic of</source>
        <translation>Macedónia, Antiga República Jugoslava da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="291"/>
        <source>Macao</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="324"/>
        <source>Pitcairn</source>
        <translation>Pitcairn</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="326"/>
        <source>Palestine, State of</source>
        <translation>Palestina, Estado da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="342"/>
        <source>Saint Helena, Ascension and Tristan da Cunha</source>
        <translation>Santa Helena, Ascensão e Tristão da Cunha</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="351"/>
        <source>South Sudan</source>
        <translation>Sudão do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="354"/>
        <source>Sint Maarten (Dutch part)</source>
        <translation>Sint Maarten (parte holandesa)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="368"/>
        <source>Turkey</source>
        <translation>Turquia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="369"/>
        <source>Trinidad and Tobago</source>
        <translation>Trinidad e Tobago</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="370"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="371"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="372"/>
        <source>Tanzania, United Republic of</source>
        <translation>Tanzânia, República Unida da</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="373"/>
        <source>Ukraine</source>
        <translation>Ucrânia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="374"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="375"/>
        <source>United States Minor Outlying Islands</source>
        <translation>Ilhas Menores Distantes dos Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="376"/>
        <source>United States</source>
        <translation>Estados Unidos</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="377"/>
        <source>Uruguay</source>
        <translation>Uruguai</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="378"/>
        <source>Uzbekistan</source>
        <translation>Uzbequistão</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="379"/>
        <source>Holy See (Vatican City State)</source>
        <translation>Santa Sé (Cidade-Estado do Vaticano)</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="380"/>
        <source>Saint Vincent and the Grenadines</source>
        <translation>São Vicente e Granadinas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="382"/>
        <source>Virgin Islands, British</source>
        <translation>Ilhas Virgens Britânicas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="383"/>
        <source>Virgin Islands, U.S.</source>
        <translation>Ilhas Virgens Americanas</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="385"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="386"/>
        <source>Wallis and Futuna</source>
        <translation>Wallis e Futuna</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="387"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="388"/>
        <source>Yemen</source>
        <translation>Iêmen</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="389"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="333"/>
        <source>Serbia</source>
        <translation>Sérvia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="390"/>
        <source>South Africa</source>
        <translation>África do Sul</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="391"/>
        <source>Zambia</source>
        <translation>Zâmbia</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="283"/>
        <source>Montenegro</source>
        <translation>Montenegro</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="392"/>
        <source>Zimbabwe</source>
        <translation>Zimbábue</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="158"/>
        <source>Aland Islands</source>
        <translation>Ilhas Aland</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="224"/>
        <source>Guernsey</source>
        <translation>Guernsey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="247"/>
        <source>Isle of Man</source>
        <translation>Ilha de Man</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="254"/>
        <source>Jersey</source>
        <translation>Jersey</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="169"/>
        <source>Saint Barthelemy</source>
        <translation>São Bartolomeu, Coletividade de</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="444"/>
        <source>Couldn&apos;t save downloaded GeoIP database file.</source>
        <translation>Não foi possível salvar o banco de dados GeoIP baixado.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="447"/>
        <source>Successfully updated GeoIP database.</source>
        <translation>Banco de dados GeoIP atualizado com sucesso.</translation>
    </message>
    <message>
        <location filename="../base/net/geoipmanager.cpp" line="462"/>
        <source>Couldn&apos;t download GeoIP database file. Reason: %1</source>
        <translation>Não foi possível baixar o banco de dados GeoIP. Motivo: %1</translation>
    </message>
</context>
<context>
    <name>Net::PortForwarder</name>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="127"/>
        <source>UPnP / NAT-PMP support [ON]</source>
        <translation>Suporte a UPnp / NAT-PMP [LIG]</translation>
    </message>
    <message>
        <location filename="../base/net/portforwarder.cpp" line="143"/>
        <source>UPnP / NAT-PMP support [OFF]</source>
        <translation>Suporte a UPnp / NAT-PMP [DESL]</translation>
    </message>
</context>
<context>
    <name>Net::Smtp</name>
    <message>
        <location filename="../base/net/smtp.cpp" line="509"/>
        <source>Email Notification Error:</source>
        <translation>E-mail de Notificação de Erro:</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <location filename="../gui/optionsdlg.ui" line="14"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="52"/>
        <source>Behavior</source>
        <translation>Comportamento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="57"/>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="62"/>
        <source>Connection</source>
        <translation>Conexão</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="67"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="72"/>
        <source>BitTorrent</source>
        <translation>BitTorrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="77"/>
        <source>RSS</source>
        <translation>RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="82"/>
        <source>Web UI</source>
        <translation>Interface Web</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="87"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="133"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="141"/>
        <source>User Interface Language:</source>
        <translation>Idioma da interface de usuário:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="169"/>
        <source>(Requires restart)</source>
        <translation>(Necessário reiniciar)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="197"/>
        <source>Transfer List</source>
        <translation>Lista de transferência</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="203"/>
        <source>Confirm when deleting torrents</source>
        <translation>Confirmar ao excluir torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="213"/>
        <source>Use alternating row colors</source>
        <extracomment>In transfer list, one every two rows will have grey background.</extracomment>
        <translation>Usar linhas alternadas de cor</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="225"/>
        <source>Hide zero and infinity values</source>
        <translation>Ocultar valores zero e infinito</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="233"/>
        <source>Always</source>
        <translation>Sempre</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="238"/>
        <source>Paused torrents only</source>
        <translation>Somente torrents pausados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="267"/>
        <source>Action on double-click</source>
        <translation>Ação do duplo clique</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="276"/>
        <source>Downloading torrents:</source>
        <translation>Baixando torrents:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="293"/>
        <location filename="../gui/optionsdlg.ui" line="319"/>
        <source>Start / Stop Torrent</source>
        <translation>Iniciar / Parar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="298"/>
        <location filename="../gui/optionsdlg.ui" line="324"/>
        <source>Open destination folder</source>
        <translation>Abrir pasta de destino</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="303"/>
        <location filename="../gui/optionsdlg.ui" line="329"/>
        <source>No action</source>
        <translation>Nenhuma ação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="311"/>
        <source>Completed torrents:</source>
        <translation>Torrents completos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="343"/>
        <source>Desktop</source>
        <translation>Área de trabalho</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="349"/>
        <source>Start qBittorrent on Windows start up</source>
        <translation>Iniciar qBittorrent quando o Windows inicializar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="356"/>
        <source>Show splash screen on start up</source>
        <translation>Mostrar imagem de início ao inicializar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="366"/>
        <source>Start qBittorrent minimized</source>
        <translation>Iniciar qBittorrent minimizado</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="373"/>
        <source>Confirmation on exit when torrents are active</source>
        <translation>Confirmação ao sair com torrents ativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="383"/>
        <source>Confirmation on auto-exit when downloads finish</source>
        <translation>Confirmação ao sair automaticamente quando concluir os downloads</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1111"/>
        <source>Email notification &amp;upon download completion</source>
        <translation>Notificação por email q&amp;uando completar o download</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1206"/>
        <source>Run e&amp;xternal program on torrent completion</source>
        <translation>Executar programa e&amp;xterno quando completar o torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1665"/>
        <source>IP Fi&amp;ltering</source>
        <translation>Fi&amp;ltro de IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1864"/>
        <source>Schedule &amp;the use of alternative rate limits</source>
        <translation>Agendar para usar &amp;taxas de limite alternativas</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2261"/>
        <source>&amp;Torrent Queueing</source>
        <translation>&amp;Torrents na Espera</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2515"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2522"/>
        <source>Seed torrents until their seeding time reaches</source>
        <translation>Semear torrents até que sua taxa de semeadura seja atingida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2538"/>
        <source>A&amp;utomatically add these trackers to new downloads:</source>
        <translation>A&amp;utomaticamente adicionar estes trackers para novos downloads:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2611"/>
        <source>RSS Reader</source>
        <translation>Leitor de RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2617"/>
        <source>Enable fetching RSS feeds</source>
        <translation>Habilitar a busca de feeds RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2626"/>
        <source>Feeds refresh interval:</source>
        <translation>Intervalo de atualização de feeds:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2636"/>
        <source>Maximum number of articles per feed:</source>
        <translation>Número máximo de artigos por feed:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2646"/>
        <source> min</source>
        <translation> min</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2690"/>
        <source>RSS Torrent Auto Downloader</source>
        <translation>Baixador automático de RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2696"/>
        <source>Enable auto downloading of RSS torrents</source>
        <translation>Habilitar download automático de torrents RSS</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2703"/>
        <source>Edit auto downloading rules...</source>
        <translation>Editar regras de download automático...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2761"/>
        <source>Web User Interface (Remote control)</source>
        <translation>Interface Web do Usuário (Controle remoto)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2775"/>
        <source>IP address:</source>
        <translation>Endereço de IP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2782"/>
        <source>IP address that the Web UI will bind to.
Specify an IPv4 or IPv6 address. You can specify &quot;0.0.0.0&quot; for any IPv4 address,
&quot;::&quot; for any IPv6 address, or &quot;*&quot; for both IPv4 and IPv6.</source>
        <translation>Endereço IP para o qual a Interface Web se conectará.
Especifique um endereço IPv4 ou IPv6. Você pode especificar &quot;0.0.0.0&quot; para qualquer endereço IPv4,
&quot;::&quot; para qualquer endereço IPv6, ou &quot;*&quot; para IPv4 e IPv6.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2815"/>
        <source>Server domains:</source>
        <translation>Domínios do servidor:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2822"/>
        <source>Whitelist for filtering HTTP Host header values.
In order to defend against DNS rebinding attack,
you should put in domain names used by WebUI server.

Use &apos;;&apos; to split multiple entries. Can use wildcard &apos;*&apos;.</source>
        <translation>A lista branca para filtrar valores de cabeçalho do host HTTP.
Para se defender contra o ataque de reinserção de DNS,
você deve colocar nomes de domínio usados pelo servidor WebUI.

Use &apos;;&apos; para dividir várias entradas. Pode usar o curinga &apos;*&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2845"/>
        <source>&amp;Use HTTPS instead of HTTP</source>
        <translation>&amp;Usar HTTPS em vez de HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3032"/>
        <source>Upda&amp;te my dynamic domain name</source>
        <translation>A&amp;tualizar meu nome de domínio dinâmico</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="402"/>
        <source>Minimize qBittorrent to notification area</source>
        <translation>Minimizar qBittorrent na área de notificação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="412"/>
        <source>Close qBittorrent to notification area</source>
        <comment>i.e: The systray tray icon will still be visible when closing the main window.</comment>
        <translation>Fechar qBittorrent para área de notificação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="421"/>
        <source>Tray icon style:</source>
        <translation>Estilo do ícone da bandeja:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="429"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="434"/>
        <source>Monochrome (Dark theme)</source>
        <translation>Monocromático (tema Escuro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="439"/>
        <source>Monochrome (Light theme)</source>
        <translation>Monocromático (tema Claro)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="452"/>
        <source>File association</source>
        <translation>Associação de arquivo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="458"/>
        <source>Use qBittorrent for .torrent files</source>
        <translation>Usar qBittorrent para arquivos .torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="465"/>
        <source>Use qBittorrent for magnet links</source>
        <translation>Usar qBittorrent para links magnéticos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="478"/>
        <source>Power Management</source>
        <translation>Gestão de Energia</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="484"/>
        <source>Inhibit system sleep when torrents are active</source>
        <translation>Sistema de espera inibe quando torrents estão ativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="514"/>
        <source>Save path:</source>
        <translation>Caminho para salvar:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="531"/>
        <source>Backup the log file after:</source>
        <translation>Fazer backup do arquivo de log após:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="538"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="574"/>
        <source>Delete backup logs older than:</source>
        <translation>Excluir logs de backup mais antigos que:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="598"/>
        <source>days</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>dias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="603"/>
        <source>months</source>
        <comment>Delete backup logs older than 10 months</comment>
        <translation>meses</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="608"/>
        <source>years</source>
        <comment>Delete backup logs older than 10 years</comment>
        <translation>anos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="682"/>
        <source>When adding a torrent</source>
        <translation>Quando adicionar um torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="700"/>
        <source>Bring torrent dialog to the front</source>
        <translation>Trazer a janela torrent para frente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="723"/>
        <source>Do not start the download automatically</source>
        <comment>The torrent will be added to download list in pause state</comment>
        <translation>Não iniciar o download automaticamente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="730"/>
        <source>Should the .torrent file be deleted after adding it</source>
        <translation>O arquivo .torrent deve ser excluído após adicioná-lo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="745"/>
        <source>Also delete .torrent files whose addition was cancelled</source>
        <translation>Também excluir arquivos .torrent cuja adição foi cancelada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="748"/>
        <source>Also when addition is cancelled</source>
        <translation>Também quando a adição foi cancelada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="770"/>
        <source>Warning! Data loss possible!</source>
        <translation>Atenção! Possibilidade de perda de dados!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="785"/>
        <source>Saving Management</source>
        <translation>Gestão de Salvamento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="793"/>
        <source>Default Torrent Management Mode:</source>
        <translation>Modo de Gerenciamento de Torrents Padrão:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="805"/>
        <source>Automatic mode means that various torrent properties (e.g. save path) will be decided by the associated category</source>
        <translation>O modo automático configura várias propriedades do torrent (ex.: caminho para salvar) baseado na categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="809"/>
        <source>Manual</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="814"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="837"/>
        <source>When Torrent Category changed:</source>
        <translation>Quando a Categoria do Torrent for alterada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="847"/>
        <source>Relocate torrent</source>
        <translation>Realocar torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="852"/>
        <source>Switch torrent to Manual Mode</source>
        <translation>Alterar torrent para Modo Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="875"/>
        <source>When Default Save Path changed:</source>
        <translation>Quando o Caminho Padrão para Salvar for alterado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="888"/>
        <location filename="../gui/optionsdlg.ui" line="929"/>
        <source>Relocate affected torrents</source>
        <translation>Realocar torrents implicados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="893"/>
        <location filename="../gui/optionsdlg.ui" line="934"/>
        <source>Switch affected torrents to Manual Mode</source>
        <translation>Alterar torrents afetados para Modo Manual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="916"/>
        <source>When Category changed:</source>
        <translation>Quando a Categoria for alterada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="959"/>
        <source>Use Subcategories</source>
        <translation>Usar Subcategorias</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="978"/>
        <source>Default Save Path:</source>
        <translation>Caminho Padrão para Salvar:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="992"/>
        <source>Keep incomplete torrents in:</source>
        <translation>Manter torrents incompletos em:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="985"/>
        <source>Copy .torrent files to:</source>
        <translation>Copiar arquivos .torrent para:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="393"/>
        <source>Show &amp;qBittorrent in notification area</source>
        <translation>Mostrar o &amp;qBittorrent na área de notificação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="494"/>
        <source>&amp;Log file</source>
        <translation>Arquivo de &amp;log</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="688"/>
        <source>Display &amp;torrent content and some options</source>
        <translation>Mostrar conteúdo do &amp;torrent e mais opções</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="713"/>
        <source>Create subfolder for torrents with multiple files</source>
        <translation>Criar subpasta para torrents com múltiplos arquivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="733"/>
        <source>De&amp;lete .torrent files afterwards </source>
        <translation>&amp;Excluir arquivos .torrent mais tarde </translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="971"/>
        <source>Copy .torrent files for finished downloads to:</source>
        <translation>Copiar arquivos .torrent finalizados para:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1010"/>
        <source>Pre-allocate disk space for all files</source>
        <translation>Pré-alocar espaço em disco para todos os arquivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1017"/>
        <source>Append .!qB extension to incomplete files</source>
        <translation>Adicionar extensão .!qB para arquivos incompletos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1027"/>
        <source>Automatically add torrents from:</source>
        <translation>Adicionar automaticamente torrents de:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1074"/>
        <source>Add entry</source>
        <translation>Adicionar entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1084"/>
        <source>Remove entry</source>
        <translation>Remover entrada</translation>
    </message>
    <message>
        <source>Destination email:</source>
        <translation type="obsolete">E-mail de destino:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1135"/>
        <source>SMTP server:</source>
        <translation>Servidor SMTP:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1157"/>
        <source>This server requires a secure connection (SSL)</source>
        <translation>Este servidor espera por uma conexão segura (SSL)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1164"/>
        <location filename="../gui/optionsdlg.ui" line="2976"/>
        <source>Authentication</source>
        <translation>Autenticação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1176"/>
        <location filename="../gui/optionsdlg.ui" line="1626"/>
        <location filename="../gui/optionsdlg.ui" line="3015"/>
        <location filename="../gui/optionsdlg.ui" line="3090"/>
        <source>Username:</source>
        <translation>Nome de usuário:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1186"/>
        <location filename="../gui/optionsdlg.ui" line="1636"/>
        <location filename="../gui/optionsdlg.ui" line="3022"/>
        <location filename="../gui/optionsdlg.ui" line="3104"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1274"/>
        <source>Enabled protocol:</source>
        <translation>Protocolo habilitado:</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="1282"/>
        <source>TCP and μTP</source>
        <translation>TCP e μTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1302"/>
        <source>Listening Port</source>
        <translation>Porta de Escuta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1310"/>
        <source>Port used for incoming connections:</source>
        <translation>Porta usada para conexões de entrada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1330"/>
        <source>Random</source>
        <translation>Aleatória</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1352"/>
        <source>Use UPnP / NAT-PMP port forwarding from my router</source>
        <translation>Usar redirecionamento de porta UPnP / NAT-PMP do meu roteador</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1362"/>
        <source>Use different port on each startup</source>
        <translation>Usar uma porta diferente a cada inicialização</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1372"/>
        <source>Connections Limits</source>
        <translation>Limites de Conexão</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1388"/>
        <source>Maximum number of connections per torrent:</source>
        <translation>Número máximo de conexões por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1398"/>
        <source>Global maximum number of connections:</source>
        <translation>Número máximo global de conexões:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1437"/>
        <source>Maximum number of upload slots per torrent:</source>
        <translation>Número máximo de slots de upload por torrent:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1447"/>
        <source>Global maximum number of upload slots:</source>
        <translation>Número máximo global de slots de upload:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1486"/>
        <source>Proxy Server</source>
        <translation>Servidor Proxy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1494"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1502"/>
        <source>(None)</source>
        <translation>(Nenhum)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1507"/>
        <source>SOCKS4</source>
        <translation>SOCKS4</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1512"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1517"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1528"/>
        <source>Host:</source>
        <translation>Servidor:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1548"/>
        <location filename="../gui/optionsdlg.ui" line="2791"/>
        <source>Port:</source>
        <translation>Porta:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1576"/>
        <source>Otherwise, the proxy server is only used for tracker connections</source>
        <translation>Caso contrário, o servidor proxy é somente usado para conexões de tracker</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1579"/>
        <source>Use proxy for peer connections</source>
        <translation>Usar proxy para conexões de peer</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1586"/>
        <source>Disable connections not supported by proxies</source>
        <translation>Desabilitar conexões não suportadas por proxy</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1596"/>
        <source>RSS feeds, search engine, software updates or anything else other than torrent transfers and related operations (such as peer exchanges) will use a direct connection</source>
        <translation>Feeds RSS, mecanismo de busca, atualizações de software ou qualquer outra coisa que não sejam transferências de torrent e operações relacionadas (tais como intercâmbio de peer) usarão conexão direta</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1599"/>
        <source>Use proxy only for torrents</source>
        <translation>Usar proxy somente para torrents</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1612"/>
        <source>A&amp;uthentication</source>
        <translation>A&amp;utenticação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1652"/>
        <source>Info: The password is saved unencrypted</source>
        <translation>Info: A senha é salva sem criptografia</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1673"/>
        <source>Filter path (.dat, .p2p, .p2b):</source>
        <translation>Caminho do filtro (.dat, .p2p, .p2b):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1689"/>
        <source>Reload the filter</source>
        <translation>Recarregar o filtro</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1704"/>
        <source>Manually banned IP addresses...</source>
        <translation>Lista de endereços IP banidos manualmente...</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1711"/>
        <source>Apply to trackers</source>
        <translation>Aplicar aos trackers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1769"/>
        <source>Global Rate Limits</source>
        <translation>Limite Global</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1791"/>
        <location filename="../gui/optionsdlg.ui" line="1982"/>
        <source>Upload:</source>
        <translation>Upload:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1798"/>
        <location filename="../gui/optionsdlg.ui" line="1821"/>
        <location filename="../gui/optionsdlg.ui" line="2028"/>
        <location filename="../gui/optionsdlg.ui" line="2035"/>
        <source>KiB/s</source>
        <translation>KB/s</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1835"/>
        <location filename="../gui/optionsdlg.ui" line="1989"/>
        <source>Download:</source>
        <translation>Download:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1858"/>
        <source>Alternative Rate Limits</source>
        <translation>Limites de Taxa Alternativos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1148"/>
        <location filename="../gui/optionsdlg.ui" line="1876"/>
        <source>From:</source>
        <extracomment>from (time1 to time2)</extracomment>
        <translation>De:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1128"/>
        <location filename="../gui/optionsdlg.ui" line="1900"/>
        <source>To:</source>
        <extracomment>time1 to time2</extracomment>
        <translation>Até:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1927"/>
        <source>When:</source>
        <translation>Quando:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1941"/>
        <source>Every day</source>
        <translation>Diariamente</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1946"/>
        <source>Weekdays</source>
        <translation>Dias de semana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="1951"/>
        <source>Weekends</source>
        <translation>Finais de semana</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2058"/>
        <source>Rate Limits Settings</source>
        <translation>Configurações de Limites de Taxa</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2078"/>
        <source>Apply rate limit to peers on LAN</source>
        <translation>Aplicar limite de taxa para peers na LAN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2071"/>
        <source>Apply rate limit to transport overhead</source>
        <translation>Aplicar taxa limite para transporte acima da carga</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2064"/>
        <source>Apply rate limit to µTP protocol</source>
        <translation>Aplicar limite de taxa para protocolo µTP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2136"/>
        <source>Privacy</source>
        <translation>Privacidade</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2142"/>
        <source>Enable DHT (decentralized network) to find more peers</source>
        <translation>Habilitar DHT (rede decentralizada) para encontrar mais peers</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/optionsdlg.ui" line="2152"/>
        <source>Exchange peers with compatible Bittorrent clients (µTorrent, Vuze, ...)</source>
        <translation>Trocar peers com clientes Bittorrent compatíveis (µTorrent, Vuze, ...)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2155"/>
        <source>Enable Peer Exchange (PeX) to find more peers</source>
        <translation>Habilitar Peer Exchange (PeX) para encontrar mais peers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2165"/>
        <source>Look for peers on your local network</source>
        <translation>Buscar por peers na rede local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2168"/>
        <source>Enable Local Peer Discovery to find more peers</source>
        <translation>Habilitar Descoberta de Peer Local para encontrar mais peers</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2180"/>
        <source>Encryption mode:</source>
        <translation>Modo de encriptação:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2188"/>
        <source>Prefer encryption</source>
        <translation>Preferir encriptação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2193"/>
        <source>Require encryption</source>
        <translation>Encriptação requerida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2198"/>
        <source>Disable encryption</source>
        <translation>Desabilitar encriptação</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2223"/>
        <source>Enable when using a proxy or a VPN connection</source>
        <translation>Habilite ao usar proxy ou uma conexão VPN</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2226"/>
        <source>Enable anonymous mode</source>
        <translation>Habilitar modo anônimo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2233"/>
        <source> (&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;More information&lt;/a&gt;)</source>
        <translation> (&lt;a href=&quot;https://github.com/qbittorrent/qBittorrent/wiki/Anonymous-Mode&quot;&gt;Mais informações&lt;/a&gt;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2276"/>
        <source>Maximum active downloads:</source>
        <translation>Máximo de downloads ativos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2296"/>
        <source>Maximum active uploads:</source>
        <translation>Máximo de uploads ativos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2316"/>
        <source>Maximum active torrents:</source>
        <translation>Máximo de torrents ativos:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2375"/>
        <source>Do not count slow torrents in these limits</source>
        <translation>Não contar torrents lentos nesses limites</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2385"/>
        <source>Share Ratio Limiting</source>
        <translation>LImite da Taxa de Compartilhamento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2391"/>
        <source>Seed torrents until their ratio reaches</source>
        <translation>Semear torrents até que sua taxa atinja</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2411"/>
        <source>then</source>
        <translation>então</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2425"/>
        <source>Pause them</source>
        <translation>Pausá-los</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2430"/>
        <source>Remove them</source>
        <translation>Removê-los</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2835"/>
        <source>Use UPnP / NAT-PMP to forward the port from my router</source>
        <translation>Usar UPnP / NAT-PMP para redirecionar a porta do meu roteador</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2876"/>
        <source>Certificate:</source>
        <translation>Certificado:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2888"/>
        <source>Import SSL Certificate</source>
        <translation>Importar Certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2929"/>
        <source>Key:</source>
        <translation>Chave:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2941"/>
        <source>Import SSL Key</source>
        <translation>Importar Chave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="2963"/>
        <source>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Information about certificates&lt;/a&gt;</source>
        <translation>&lt;a href=https://httpd.apache.org/docs/current/ssl/ssl_faq.html#aboutcerts&gt;Informações sobre certificados&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3008"/>
        <source>Bypass authentication for localhost</source>
        <translation>Ignorar autenticação para host local</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3044"/>
        <source>Service:</source>
        <translation>Serviço:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3067"/>
        <source>Register</source>
        <translation>Registrar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.ui" line="3076"/>
        <source>Domain name:</source>
        <translation>Nome do domínio:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="112"/>
        <source>By enabling these options, you can &lt;strong&gt;irrevocably lose&lt;/strong&gt; your .torrent files!</source>
        <translation>Ao habilitar estas opções, você pode &lt;strong&gt;definitivamente perder&lt;/strong&gt; seus arquivos .torrent!</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="114"/>
        <source>When these options are enabled, qBittorent will &lt;strong&gt;delete&lt;/strong&gt; .torrent files after they were successfully (the first option) or not (the second option) added to its download queue. This will be applied &lt;strong&gt;not only&lt;/strong&gt; to the files opened via &amp;ldquo;Add torrent&amp;rdquo; menu action but to those opened via &lt;strong&gt;file type association&lt;/strong&gt; as well</source>
        <translation>Quando estas opções estiverem habilitadas, o qBittorrent irá &lt;strong&gt;excluir&lt;/strong&gt; os arquivos .torrent após eles serem adicionados com sucesso (primeira opção) ou não (segunda opção) em suas filas filas de download. Isto será aplicado &lt;strong&gt;não somente&lt;/strong&gt; aos arquivos abertos pelo menu &amp;ldquo;Adicionar torrent&amp;rdquo;, mas também para aqueles abertos pela &lt;strong&gt;associação de tipos de arquivo&lt;/strong&gt;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="119"/>
        <source>If you enable the second option (&amp;ldquo;Also when addition is cancelled&amp;rdquo;) the .torrent file &lt;strong&gt;will be deleted&lt;/strong&gt; even if you press &amp;ldquo;&lt;strong&gt;Cancel&lt;/strong&gt;&amp;rdquo; in the &amp;ldquo;Add torrent&amp;rdquo; dialog</source>
        <translation>Se você habilitar a segunda opção (&amp;ldquo;Também se a adição for cancelada&amp;rdquo;) o arquivo .torrent &lt;strong&gt;será excluído&lt;/strong&gt; mesmo se você pressionar &amp;ldquo;&lt;strong&gt;Cancelar&lt;/strong&gt;&amp;rdquo; no diálogo &amp;ldquo;Adicionar torrent&amp;rdquo;</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="262"/>
        <source>Supported parameters (case sensitive):</source>
        <translation>Parâmetros suportados (diferencia maiúsculas de minúsculas):</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="263"/>
        <source>%N: Torrent name</source>
        <translation>%N: Nome do torrent</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="264"/>
        <source>%L: Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="265"/>
        <source>%F: Content path (same as root path for multifile torrent)</source>
        <translation>%F: Caminho de conteúdo (mesmo do caminho raiz para torrent multi arquivo)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="266"/>
        <source>%R: Root path (first torrent subdirectory path)</source>
        <translation>%R: Caminho raiz (caminho da subpasta do primeiro torrent)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="267"/>
        <source>%D: Save path</source>
        <translation>%D: Caminho para salvar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="268"/>
        <source>%C: Number of files</source>
        <translation>%C: Número de arquivos</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="269"/>
        <source>%Z: Torrent size (bytes)</source>
        <translation>%Z: Tamanho do torrent (bytes)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="270"/>
        <source>%T: Current tracker</source>
        <translation>%T: Tracker atual</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="271"/>
        <source>%I: Info hash</source>
        <translation>%I: Informação de hash</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="272"/>
        <source>Tip: Encapsulate parameter with quotation marks to avoid text being cut off at whitespace (e.g., &quot;%N&quot;)</source>
        <translation>Dica: Coloque o parâmetro entre aspas para evitar que o texto seja cortado nos espaços em branco (ex.: &quot;%N&quot;)</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1443"/>
        <source>Select folder to monitor</source>
        <translation>Selecione a pasta para monitorar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1450"/>
        <source>Folder is already being monitored:</source>
        <translation>A pasta já está sendo monitorada:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1453"/>
        <source>Folder does not exist:</source>
        <translation>Essa pasta não existe:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1456"/>
        <source>Folder is not readable:</source>
        <translation>A pasta não possui suporte para leitura:</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1467"/>
        <source>Adding entry failed</source>
        <translation>Falha ao adicionar entrada</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="379"/>
        <location filename="../gui/optionsdlg.cpp" line="382"/>
        <location filename="../gui/optionsdlg.cpp" line="1495"/>
        <location filename="../gui/optionsdlg.cpp" line="1497"/>
        <source>Choose export directory</source>
        <translation>Escolha a pasta para exportar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="376"/>
        <location filename="../gui/optionsdlg.cpp" line="389"/>
        <location filename="../gui/optionsdlg.cpp" line="392"/>
        <source>Choose a save directory</source>
        <translation>Escolha a pasta para salvar</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="385"/>
        <source>Choose an IP filter file</source>
        <translation>Escolha um arquivo de filtro de IP</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="386"/>
        <source>All supported filters</source>
        <translation>Todos os filtros suportados</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1531"/>
        <source>SSL Certificate</source>
        <translation>Certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1581"/>
        <source>Parsing error</source>
        <translation>Erro de análise</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1581"/>
        <source>Failed to parse the provided IP filter</source>
        <translation>Falha ao analisar filtro de IP fornecido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1583"/>
        <source>Successfully refreshed</source>
        <translation>Atualizado com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1583"/>
        <source>Successfully parsed the provided IP filter: %1 rules were applied.</source>
        <comment>%1 is a number</comment>
        <translation>Filtro de IP fornecido analisado com sucesso: %1 regras foram aplicadas.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1556"/>
        <source>Invalid key</source>
        <translation>Chave inválida</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1556"/>
        <source>This is not a valid SSL key.</source>
        <translation>Esta não é uma chave SSL válida.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1541"/>
        <source>Invalid certificate</source>
        <translation>Certificado inválido</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="85"/>
        <source>Preferences</source>
        <translation>Preferências</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1531"/>
        <source>Import SSL certificate</source>
        <translation>Importar certificado SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1541"/>
        <source>This is not a valid SSL certificate.</source>
        <translation>Este não é um certificado SSL válido.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1546"/>
        <source>Import SSL key</source>
        <translation>Importar chave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1546"/>
        <source>SSL key</source>
        <translation>Chave SSL</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1706"/>
        <source>Time Error</source>
        <translation>Erro de Tempo</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1706"/>
        <source>The start time and the end time can&apos;t be the same.</source>
        <translation>O tempo inicial e final não pode ser igual.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1715"/>
        <location filename="../gui/optionsdlg.cpp" line="1719"/>
        <source>Length Error</source>
        <translation>Erro de Comprimento</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1715"/>
        <source>The Web UI username must be at least 3 characters long.</source>
        <translation>O nome de usuário para a interface Web deve conter mais que 3 caracteres.</translation>
    </message>
    <message>
        <location filename="../gui/optionsdlg.cpp" line="1719"/>
        <source>The Web UI password must be at least 6 characters long.</source>
        <translation>A senha de usuário da interface Web deve ser maior que 3 caracteres.</translation>
    </message>
</context>
<context>
    <name>PeerInfo</name>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="280"/>
        <source>interested(local) and choked(peer)</source>
        <translation>interessados​​(local) e paralisar(peer)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="286"/>
        <source>interested(local) and unchoked(peer)</source>
        <translation>interessados(local) e paralisados(peer)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="295"/>
        <source>interested(peer) and choked(local)</source>
        <translation>interessados(peer) e paralisados(local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="301"/>
        <source>interested(peer) and unchoked(local)</source>
        <translation>interessado (peer) e unchoked (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="309"/>
        <source>optimistic unchoke</source>
        <translation>unchoke otimista</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="316"/>
        <source>peer snubbed</source>
        <translation>peer esnobado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="323"/>
        <source>incoming connection</source>
        <translation>conexão de entrada</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="330"/>
        <source>not interested(local) and unchoked(peer)</source>
        <translation>não está interessado (local) e unchoked (peer)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="337"/>
        <source>not interested(peer) and unchoked(local)</source>
        <translation>não está interessado (peer) e unchoked (local)</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="344"/>
        <source>peer from PEX</source>
        <translation>peer de PEX</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="351"/>
        <source>peer from DHT</source>
        <translation>peer de DHT</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="358"/>
        <source>encrypted traffic</source>
        <translation>tráfego criptografado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="365"/>
        <source>encrypted handshake</source>
        <translation>handshake criptografado</translation>
    </message>
    <message>
        <location filename="../base/bittorrent/peerinfo.cpp" line="379"/>
        <source>peer from LSD</source>
        <translation>peer de LSD</translation>
    </message>
</context>
<context>
    <name>PeerListWidget</name>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="72"/>
        <source>IP</source>
        <translation>IP</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="73"/>
        <source>Port</source>
        <translation>Porta</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="74"/>
        <source>Flags</source>
        <translation>Bandeiras</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="75"/>
        <source>Connection</source>
        <translation>Conexão</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="76"/>
        <source>Client</source>
        <comment>i.e.: Client application</comment>
        <translation>Cliente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="77"/>
        <source>Progress</source>
        <comment>i.e: % downloaded</comment>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="78"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Velocidade de download</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="79"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocidade de upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="80"/>
        <source>Downloaded</source>
        <comment>i.e: total data downloaded</comment>
        <translation>Baixado</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="81"/>
        <source>Uploaded</source>
        <comment>i.e: total data uploaded</comment>
        <translation>Subido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="82"/>
        <source>Relevance</source>
        <comment>i.e: How relevant this peer is to us. How many pieces it has that we don&apos;t.</comment>
        <translation>Relevância</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="83"/>
        <source>Files</source>
        <comment>i.e. files that are being downloaded right now</comment>
        <translation>Arquivos</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="154"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="231"/>
        <source>Add a new peer...</source>
        <translation>Adicionar um novo peer...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="239"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="277"/>
        <source>Ban peer permanently</source>
        <translation>Banir fonte permanentemente</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="251"/>
        <source>Manually adding peer &apos;%1&apos;...</source>
        <translation>Adicionando manualmente peer %1...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="255"/>
        <source>The peer &apos;%1&apos; could not be added to this torrent.</source>
        <translation>O peer &apos;%1&apos; não pôde ser adicionado a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="288"/>
        <source>Manually banning peer &apos;%1&apos;...</source>
        <translation>Banindo manualmente peer &apos;%1&apos;...</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <location filename="../gui/properties/peerlistwidget.cpp" line="261"/>
        <source>Peer addition</source>
        <translation>Adição de fonte</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="71"/>
        <source>Country</source>
        <translation>País</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="237"/>
        <source>Copy IP:port</source>
        <translation>Copiar IP:porta</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="259"/>
        <source>Some peers could not be added. Check the Log for details.</source>
        <translation>Alguns peers não puderam ser adicionados. Veja o Log para detalhes.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="261"/>
        <source>The peers were added to this torrent.</source>
        <translation>Peers adicionados a este torrent.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="277"/>
        <source>Are you sure you want to ban permanently the selected peers?</source>
        <translation>Deseja mesmo banir permanentemente a fonte selecionada?</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>&amp;Yes</source>
        <translation>&amp;Sim</translation>
    </message>
    <message>
        <location filename="../gui/properties/peerlistwidget.cpp" line="278"/>
        <source>&amp;No</source>
        <translation>&amp;Não</translation>
    </message>
</context>
<context>
    <name>PeersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="64"/>
        <source>No peer entered</source>
        <translation>Nenhum peer inserida</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="65"/>
        <source>Please type at least one peer.</source>
        <translation>Por favor, entre pelo menos um peer.</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="75"/>
        <source>Invalid peer</source>
        <translation>Peer inválido</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.cpp" line="76"/>
        <source>The peer &apos;%1&apos; is invalid.</source>
        <translation>O peer &apos;%1&apos; é inválido.</translation>
    </message>
</context>
<context>
    <name>PieceAvailabilityBar</name>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="163"/>
        <source>White: Unavailable pieces</source>
        <translation>Branco: Pedaços indisponíveis</translation>
    </message>
    <message>
        <location filename="../gui/properties/pieceavailabilitybar.cpp" line="164"/>
        <source>Blue: Available pieces</source>
        <translation>Azul: Pedaços disponíveis</translation>
    </message>
</context>
<context>
    <name>PiecesBar</name>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="266"/>
        <source>Files in this piece:</source>
        <translation>Arquivos neste pedaço:</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="270"/>
        <source>File in this piece</source>
        <translation>Arquivo neste pedaço</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="272"/>
        <source>File in these pieces</source>
        <translation>Arquivo nestes pedaços</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="291"/>
        <source>Wait until metadata become available to see detailed information</source>
        <translation>Aguarde até que os metadados estejam disponíveis para ver informação detalhada</translation>
    </message>
    <message>
        <location filename="../gui/properties/piecesbar.cpp" line="293"/>
        <source>Hold Shift key for detailed information</source>
        <translation>Pressione a tecla Shift para informações detalhadas</translation>
    </message>
</context>
<context>
    <name>PluginSelectDlg</name>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="17"/>
        <source>Search plugins</source>
        <translation>Plugins de pesquisa</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="30"/>
        <source>Installed search plugins:</source>
        <translation>Plugins de pesquisa instalados:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="53"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="58"/>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="63"/>
        <source>Url</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="68"/>
        <location filename="../gui/search/pluginselectdlg.ui" line="134"/>
        <source>Enabled</source>
        <translation>Ativado</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="81"/>
        <source>Warning: Be sure to comply with your country&apos;s copyright laws when downloading torrents from any of these search engines.</source>
        <translation>Aviso: Certifique-se de observar as leis de copyright do seu país ao baixar torrents de qualquer um destes mecanismos de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="96"/>
        <source>You can get new search engine plugins here: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</source>
        <translation>Você pode obter novos plugins de mecanismos de pesquisa aqui: &lt;a href=&quot;http://plugins.qbittorrent.org&quot;&gt;http://plugins.qbittorrent.org&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="108"/>
        <source>Install a new one</source>
        <translation>Instalar um novo</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="115"/>
        <source>Check for updates</source>
        <translation>Verificar atualizações</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="122"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.ui" line="139"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="162"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="224"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="283"/>
        <source>Yes</source>
        <translation>Sim</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="166"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="205"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="228"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="287"/>
        <source>No</source>
        <translation>Não</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="211"/>
        <source>Uninstall warning</source>
        <translation>Aviso de desinstalação</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="211"/>
        <source>Some plugins could not be uninstalled because they are included in qBittorrent. Only the ones you added yourself can be uninstalled.
Those plugins were disabled.</source>
        <translation>Alguns plugins não puderam ser desinstalados pois estão incluídos no qBittorrent. Somente aqueles que você mesmo adicionou podem ser desinstalados.
Esses plugins foram desativados.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="213"/>
        <source>Uninstall success</source>
        <translation>Desinstalado com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="213"/>
        <source>All selected plugins were uninstalled successfully</source>
        <translation>Todos os plugins selecionados foram desinstalados com sucesso</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="325"/>
        <source>Plugins installed or updated: %1</source>
        <translation>Plugins instalados ou atualizados: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="345"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="352"/>
        <source>New search engine plugin URL</source>
        <translation>URL de novo plugin de pesquisa</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="346"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="353"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="350"/>
        <source>Invalid link</source>
        <translation>Link inválido</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="350"/>
        <source>The link doesn&apos;t seem to point to a search engine plugin.</source>
        <translation>Esse link não parece estar apontando para um plugin de motor de busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="366"/>
        <source>Select search plugins</source>
        <translation>Selecionar plugins de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="367"/>
        <source>qBittorrent search plugin</source>
        <translation>Plugin de busca do qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="325"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="424"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="438"/>
        <location filename="../gui/search/pluginselectdlg.cpp" line="469"/>
        <source>Search plugin update</source>
        <translation>Atualização de plugin de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="424"/>
        <source>All your plugins are already up to date.</source>
        <translation>Todos os plugins já estão atuais.</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="438"/>
        <source>Sorry, couldn&apos;t check for plugin updates. %1</source>
        <translation>Desculpe, não foi possível verificar por atualizações do plugin: %1</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="452"/>
        <source>Search plugin install</source>
        <translation>Instalação de plugin de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="452"/>
        <source>Couldn&apos;t install &quot;%1&quot; search engine plugin. %2</source>
        <translation>Não foi possível instalar o plugin do motor de busca &quot;%1&quot;. %2</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginselectdlg.cpp" line="469"/>
        <source>Couldn&apos;t update &quot;%1&quot; search engine plugin. %2</source>
        <translation>Não foi possível atualizar o plugin do motor de busca &quot;%1&quot;. %2</translation>
    </message>
</context>
<context>
    <name>PluginSourceDlg</name>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="14"/>
        <source>Plugin source</source>
        <translation>Fonte do plugin</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="27"/>
        <source>Search plugin source:</source>
        <translation>Fonte do plugin de busca:</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="36"/>
        <source>Local file</source>
        <translation>Arquivo local</translation>
    </message>
    <message>
        <location filename="../gui/search/pluginsourcedlg.ui" line="43"/>
        <source>Web link</source>
        <translation>Link da net</translation>
    </message>
</context>
<context>
    <name>PreviewSelectDialog</name>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="54"/>
        <source>Preview</source>
        <translation>Prévia</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="61"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="62"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="63"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="96"/>
        <location filename="../gui/previewselectdialog.cpp" line="141"/>
        <source>Preview impossible</source>
        <translation>Impossível pré-visualizar</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.cpp" line="96"/>
        <location filename="../gui/previewselectdialog.cpp" line="141"/>
        <source>Sorry, we can&apos;t preview this file</source>
        <translation>Desculpe, não é possível pré-visualizar este arquivo</translation>
    </message>
</context>
<context>
    <name>Private::FileLineEdit</name>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="305"/>
        <source>&apos;%1&apos; does not exist</source>
        <translation>&apos;%1&apos; não existe</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="307"/>
        <source>&apos;%1&apos; does not point to a directory</source>
        <translation>&apos;%1&apos; não aponta para um diretório</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="309"/>
        <source>&apos;%1&apos; does not point to a file</source>
        <translation>&apos;%1&apos; não aponta para um arquivo</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="311"/>
        <source>Does not have read permission in &apos;%1&apos;</source>
        <translation>Não há permissão de leitura em &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../gui/fspathedit_p.cpp" line="313"/>
        <source>Does not have write permission in &apos;%1&apos;</source>
        <translation>Não há permissão de escritura em &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>PropListDelegate</name>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="120"/>
        <source>Not downloaded</source>
        <translation>Não baixado</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="129"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="191"/>
        <source>Normal</source>
        <comment>Normal (priority)</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="138"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="190"/>
        <source>Do not download</source>
        <comment>Do not download (priority)</comment>
        <translation>Não baixar</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="123"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="192"/>
        <source>High</source>
        <comment>High (priority)</comment>
        <translation>Alta</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="117"/>
        <source>Mixed</source>
        <comment>Mixed (priorities</comment>
        <translation>Misto</translation>
    </message>
    <message>
        <location filename="../gui/properties/proplistdelegate.cpp" line="126"/>
        <location filename="../gui/properties/proplistdelegate.cpp" line="193"/>
        <source>Maximum</source>
        <comment>Maximum (priority)</comment>
        <translation>Máxima</translation>
    </message>
</context>
<context>
    <name>PropTabBar</name>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="50"/>
        <source>General</source>
        <translation>Geral</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="59"/>
        <source>Trackers</source>
        <translation>Rastreadores</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="68"/>
        <source>Peers</source>
        <translation>Peers</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="77"/>
        <source>HTTP Sources</source>
        <translation>Fontes HTTP</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="86"/>
        <source>Content</source>
        <translation>Conteúdo</translation>
    </message>
    <message>
        <location filename="../gui/properties/proptabbar.cpp" line="97"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
</context>
<context>
    <name>PropertiesWidget</name>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="330"/>
        <source>Downloaded:</source>
        <translation>Baixado:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="107"/>
        <source>Availability:</source>
        <translation>Disponível:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="78"/>
        <source>Progress:</source>
        <translation>Progresso:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="154"/>
        <source>Transfer</source>
        <translation>Transferência</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="546"/>
        <source>Time Active:</source>
        <extracomment>Time (duration) the torrent is active (not paused)</extracomment>
        <translation>Tempo Ativo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="575"/>
        <source>ETA:</source>
        <translation>Tempo Restante:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="504"/>
        <source>Uploaded:</source>
        <translation>Subido:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="433"/>
        <source>Seeds:</source>
        <translation>Seeds:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="449"/>
        <source>Download Speed:</source>
        <translation>Velocidade de Download:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="185"/>
        <source>Upload Speed:</source>
        <translation>Velocidade de Upload:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="214"/>
        <source>Peers:</source>
        <translation>Peers:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="272"/>
        <source>Download Limit:</source>
        <translation>Limite de Download:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="346"/>
        <source>Upload Limit:</source>
        <translation>Limite de Upload:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="591"/>
        <source>Wasted:</source>
        <translation>Gasto:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="230"/>
        <source>Connections:</source>
        <translation>Conexões:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="604"/>
        <source>Information</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="863"/>
        <source>Comment:</source>
        <translation>Comentário:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1020"/>
        <source>Select All</source>
        <translation>Seleciona todos</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1027"/>
        <source>Select None</source>
        <translation>Selecionar nenhum</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1103"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1098"/>
        <source>High</source>
        <translation>Alto</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="288"/>
        <source>Share Ratio:</source>
        <translation>Proporção de compartilhamento:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="404"/>
        <source>Reannounce In:</source>
        <translation>Reanunciar em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="362"/>
        <source>Last Seen Complete:</source>
        <translation>Última Vez Visto Completo:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="622"/>
        <source>Total Size:</source>
        <translation>Tamanho Total:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="651"/>
        <source>Pieces:</source>
        <translation>Pedaços:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="680"/>
        <source>Created By:</source>
        <translation>Criado por:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="709"/>
        <source>Added On:</source>
        <translation>Adicionado em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="738"/>
        <source>Completed On:</source>
        <translation>Concluído em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="767"/>
        <source>Created On:</source>
        <translation>Criado em:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="796"/>
        <source>Torrent Hash:</source>
        <translation>Hash do torrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="828"/>
        <source>Save Path:</source>
        <translation>Caminho para Salvar:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1093"/>
        <source>Maximum</source>
        <translation>Máximo</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.ui" line="1085"/>
        <location filename="../gui/properties/propertieswidget.ui" line="1088"/>
        <source>Do not download</source>
        <translation>Não baixar</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="447"/>
        <source>Never</source>
        <translation>Nunca</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="454"/>
        <source>%1 x %2 (have %3)</source>
        <comment>(torrent pieces) eg 152 x 4MB (have 25)</comment>
        <translation>%1 x %2 (possui %3)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="399"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="402"/>
        <source>%1 (%2 this session)</source>
        <translation>%1 (%2 nesta sessão)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="411"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (semeado por %2)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="418"/>
        <source>%1 (%2 max)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 max)</comment>
        <translation>%1 (%2 máx.)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="431"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="435"/>
        <source>%1 (%2 total)</source>
        <comment>%1 and %2 are numbers, e.g. 3 (10 total)</comment>
        <translation>%1 (%2 total)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="439"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="443"/>
        <source>%1 (%2 avg.)</source>
        <comment>%1 and %2 are speed rates, e.g. 200KiB/s (100KiB/s avg.)</comment>
        <translation>%1 (%2 média)</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="590"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="591"/>
        <source>Open Containing Folder</source>
        <translation>Abrir pasta</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="592"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="597"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="647"/>
        <source>New Web seed</source>
        <translation>Novo seed web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="653"/>
        <source>Remove Web seed</source>
        <translation>Remover seed web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="655"/>
        <source>Copy Web seed URL</source>
        <translation>Copiar link do seed web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="656"/>
        <source>Edit Web seed URL</source>
        <translation>Editar o link seed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="684"/>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="716"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="754"/>
        <source>This name is already in use in this folder. Please use a different name.</source>
        <translation>Este nome já está sendo utilizado nessa pasta. Por favor use um nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="753"/>
        <source>The folder could not be renamed</source>
        <translation>A pasta não pode ser renomeada</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="860"/>
        <source>qBittorrent</source>
        <translation>qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="90"/>
        <source>Filter files...</source>
        <translation>Arquivos de filtro...</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="684"/>
        <source>Renaming</source>
        <translation>Renomeando</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="689"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="715"/>
        <source>Rename error</source>
        <translation>Erro ao renomear</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="690"/>
        <source>The name is empty or contains forbidden characters, please choose a different one.</source>
        <translation>O nome está vazio ou contém caracteres proibidos. Por favor escolha um nome diferente.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="800"/>
        <source>New URL seed</source>
        <comment>New HTTP source</comment>
        <translation>Nova URL de seed</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="801"/>
        <source>New URL seed:</source>
        <translation>Nova URL de seed:</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="807"/>
        <location filename="../gui/properties/propertieswidget.cpp" line="861"/>
        <source>This URL seed is already in the list.</source>
        <translation>Essa URL de seed já está na lista.</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="853"/>
        <source>Web seed editing</source>
        <translation>Editando o seed web</translation>
    </message>
    <message>
        <location filename="../gui/properties/propertieswidget.cpp" line="854"/>
        <source>Web seed URL:</source>
        <translation>Link de seed web:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../webui/abstractwebapplication.cpp" line="135"/>
        <source>Your IP address has been banned after too many failed authentication attempts.</source>
        <translation>Seu endereço IP foi banido após muitas falhas de autenticação.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="497"/>
        <source>Error: &apos;%1&apos; is not a valid torrent file.
</source>
        <translation>Erro: &apos;%1&apos; não é um arquivo torrent válido.
</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="515"/>
        <source>Error: Could not add torrent to session.</source>
        <translation>Erro: Não foi possível adicionar o torrent à sessão.</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="490"/>
        <source>I/O Error: Could not create temporary file.</source>
        <translation>Erro de E/S: Não foi possível criar arquivo temporário.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="147"/>
        <source>%1 is an unknown command line parameter.</source>
        <comment>--random-parameter is an unknown command line parameter.</comment>
        <translation>%1 é um parâmetro de linha de comando desconhecido.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="157"/>
        <location filename="../app/main.cpp" line="166"/>
        <source>%1 must be the single command line parameter.</source>
        <translation>%1 deve ser o único parâmetro da linha de comando.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="189"/>
        <source>You cannot use %1: qBittorrent is already running for this user.</source>
        <translation>Você não pode usar%1: qBittorrent já está em execução para este usuário.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="521"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="524"/>
        <source>Options:</source>
        <translation>Opções:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="158"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=value&apos;</comment>
        <translation>O parâmetro &apos;%1&apos; precisa seguir a sintaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="204"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--webui-port&apos; must follow syntax &apos;--webui-port=&lt;value&gt;&apos;</comment>
        <translation>O parâmetro &apos;%1&apos; precisa seguir a sintaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="218"/>
        <source>Expected integer number in environment variable &apos;%1&apos;, but got &apos;%2&apos;</source>
        <translation>Número inteiro esperado na variável de ambiente &apos;%1&apos;, mas obteve &apos;%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="271"/>
        <source>Parameter &apos;%1&apos; must follow syntax &apos;%1=%2&apos;</source>
        <comment>e.g. Parameter &apos;--add-paused&apos; must follow syntax &apos;--add-paused=&lt;true|false&gt;&apos;</comment>
        <translation>O parâmetro &apos;%1&apos; precisa seguir a sintaxe &apos;%1=%2&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="295"/>
        <source>Expected %1 in environment variable &apos;%2&apos;, but got &apos;%3&apos;</source>
        <translation>%1 esperado na variável de ambiente &apos;%2&apos;, mas obteve &apos;%3&apos;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="529"/>
        <source>port</source>
        <translation>porta</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="420"/>
        <source>%1 must specify a valid port (1 to 65535).</source>
        <translation>%1 deve especificar uma porta válida (1 até 65535).</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="526"/>
        <source>Display program version and exit</source>
        <translation>Mostra a versão do programa e sai</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="528"/>
        <source>Display this help message and exit</source>
        <translation>Mostra esta mensagem de ajuda e sai</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="530"/>
        <source>Change the Web UI port</source>
        <translation>Altera a porta da Interface Web</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="533"/>
        <source>Disable splash screen</source>
        <translation>Desabilitar tela de inicio</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="535"/>
        <source>Run in daemon-mode (background)</source>
        <translation>Executar em modo daemon (background)</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="538"/>
        <source>dir</source>
        <extracomment>Use appropriate short form or abbreviation of &quot;directory&quot;</extracomment>
        <translation>dir</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="539"/>
        <source>Store configuration files in &lt;dir&gt;</source>
        <translation>Guardar arquivos de configuração em &lt;dir&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="540"/>
        <location filename="../app/cmdoptions.cpp" line="556"/>
        <source>name</source>
        <translation>nome</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="541"/>
        <source>Store configuration files in directories qBittorrent_&lt;name&gt;</source>
        <translation>Guardar arquivos de configuração nos diretórios qBittorrent_&lt;name&gt;</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="543"/>
        <source>Hack into libtorrent fastresume files and make file paths relative to the profile directory</source>
        <translation>Alterar arquivos de resumo rápido libtorrent e criar caminhos de arquivos relativos à pasta do perfil</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="548"/>
        <source>files or URLs</source>
        <translation>arquivos ou URLs</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="549"/>
        <source>Download the torrents passed by the user</source>
        <translation>Baixa os arquivos fornecidos pelo usuário</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="563"/>
        <source>Specify whether the &quot;Add New Torrent&quot; dialog opens when adding a torrent.</source>
        <translation>Especifica quando o diálogo &quot;Adicionar Novo Torrent&quot; será aberto ao adicionar um torrent.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="552"/>
        <source>Options when adding new torrents:</source>
        <translation>Opções ao adicionar novos torrents:</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="546"/>
        <source>Shortcut for %1</source>
        <comment>Shortcut for --profile=&lt;exe dir&gt;/profile --relative-fastresume</comment>
        <translation>Atalho para %1</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>path</source>
        <translation>caminho</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="553"/>
        <source>Torrent save path</source>
        <translation>Caminho para salvar torrent</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="554"/>
        <source>Add torrents as started or paused</source>
        <translation>Adicionar torrents como iniciados ou pausados</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="555"/>
        <source>Skip hash check</source>
        <translation>Pular verificação de hash</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="557"/>
        <source>Assign torrents to category. If the category doesn&apos;t exist, it will be created.</source>
        <translation>Atribua torrents à categoria. Se a categoria não existir, ela será criada.</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="559"/>
        <source>Download files in sequential order</source>
        <translation>Baixar arquivos em ordem sequencial</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="561"/>
        <source>Download first and last pieces first</source>
        <translation>Baixar a primeira e a última parte primeiro</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="567"/>
        <source>Option values may be supplied via environment variables. For option named &apos;parameter-name&apos;, environment variable name is &apos;QBT_PARAMETER_NAME&apos; (in upper case, &apos;-&apos; replaced with &apos;_&apos;). To pass flag values, set the variable to &apos;1&apos; or &apos;TRUE&apos;. For example, to disable the splash screen: </source>
        <translation>Os valores das opções podem ser fornecidos através de variáveis de ambiente. Para a opção denominada &apos;parameter-name&apos;, o nome da variável de ambiente é &apos;QBT_PARAMETER_NAME&apos; (em maiúsculas, &apos;-&apos; substituído por &apos;_&apos;). Para passar os valores do sinalizador, defina a variável como &apos;1&apos; ou &apos;TRUE&apos;. Por exemplo, para desativar a tela inicial: </translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="572"/>
        <source>Command line parameters take precedence over environment variables</source>
        <translation>Os parâmetros da linha de comando têm precedência sobre as variáveis de ambiente</translation>
    </message>
    <message>
        <location filename="../app/cmdoptions.cpp" line="583"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="350"/>
        <source>Run application with -h option to read about command line parameters.</source>
        <translation>Execute a aplicação com a opção -h para ler sobre os parâmetros da linha de comando.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="352"/>
        <source>Bad command line</source>
        <translation>Comando errado</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="358"/>
        <source>Bad command line: </source>
        <translation>Comando errado: </translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="371"/>
        <source>Legal Notice</source>
        <translation>Notícia Legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="372"/>
        <location filename="../app/main.cpp" line="382"/>
        <source>qBittorrent is a file sharing program. When you run a torrent, its data will be made available to others by means of upload. Any content you share is your sole responsibility.

No further notices will be issued.</source>
        <translation>O qBittorrent é um programa de compartilhamento de arquivos. Quando você executa um torrent, seus dados serão disponibilizados a terceiros por meio de upload. Qualquer conteúdo que você compartilha é de sua exclusiva responsabilidade.

Não serão exibidos mais avisos.</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="373"/>
        <source>Press %1 key to accept and continue...</source>
        <translation>Pressione a tecla %1 para aceitar e continuar...</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="383"/>
        <source>Legal notice</source>
        <translation>Notícia legal</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="384"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../app/main.cpp" line="385"/>
        <source>I Agree</source>
        <translation>Eu aceito</translation>
    </message>
    <message>
        <source>Torrent name: %1</source>
        <translation type="obsolete">Nome do torrent: %1</translation>
    </message>
    <message>
        <source>Torrent size: %1</source>
        <translation type="obsolete">Tamanho do torrent: %1</translation>
    </message>
    <message>
        <source>Save path: %1</source>
        <translation type="obsolete">Caminho para salvar: %1</translation>
    </message>
    <message>
        <source>The torrent was downloaded in %1.</source>
        <comment>The torrent was downloaded in 1 hour and 20 seconds</comment>
        <translation type="obsolete">O torrent foi baixado em %1.</translation>
    </message>
    <message>
        <source>Thank you for using qBittorrent.</source>
        <translation type="obsolete">Obrigado por usar o qBittorrent.</translation>
    </message>
    <message>
        <source>[qBittorrent] &apos;%1&apos; has finished downloading</source>
        <translation type="obsolete">[qBittorrent] %1 terminou de ser baixado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="205"/>
        <source>The remote host name was not found (invalid hostname)</source>
        <translation>O host remoto não foi encontrado (host inválido)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="207"/>
        <source>The operation was canceled</source>
        <translation>A operação foi cancelada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="209"/>
        <source>The remote server closed the connection prematurely, before the entire reply was received and processed</source>
        <translation>O servidor remoto fechou a conexão prematuramente, antes da resposta completa ter sido recebida e processada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="211"/>
        <source>The connection to the remote server timed out</source>
        <translation>A conexão com o servidor remoto atingiu o tempo limite</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="213"/>
        <source>SSL/TLS handshake failed</source>
        <translation>Handshake SSL/TLS falhou</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="215"/>
        <source>The remote server refused the connection</source>
        <translation>O servidor remoto recusou a conexão</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="217"/>
        <source>The connection to the proxy server was refused</source>
        <translation>A conexão com servidor proxy foi recusada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="219"/>
        <source>The proxy server closed the connection prematurely</source>
        <translation>O servidor proxy fechou a conexão prematuramente</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="221"/>
        <source>The proxy host name was not found</source>
        <translation>O nome do host do proxy não foi encontrado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="223"/>
        <source>The connection to the proxy timed out or the proxy did not reply in time to the request sent</source>
        <translation>Fim do tempo de conexão com o proxy ou o proxy não respondeu no tempo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="225"/>
        <source>The proxy requires authentication in order to honor the request but did not accept any credentials offered</source>
        <translation>O proxy requer autenticação mas não aceitou as credenciais oferecidas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="227"/>
        <source>The access to the remote content was denied (401)</source>
        <translation>O acesso ao conteúdo remoto foi negado (401)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="229"/>
        <source>The operation requested on the remote content is not permitted</source>
        <translation>A operação solicitada no conteúdo remoto não foi permitida</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="231"/>
        <source>The remote content was not found at the server (404)</source>
        <translation>O conteúdo remoto não foi encontrado no servidor (404)</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="233"/>
        <source>The remote server requires authentication to serve the content but the credentials provided were not accepted</source>
        <translation>O servidor remoto requer autenticação para fornecer os dados, mas as credenciais oferecidas não foram aceitas</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="235"/>
        <source>The Network Access API cannot honor the request because the protocol is not known</source>
        <translation>A API de Acesso à Rede não pôde honrar o pedido pois o protocolo é desconhecido</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="237"/>
        <source>The requested operation is invalid for this protocol</source>
        <translation>A operação solicitada é inválida para este protocolo</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="239"/>
        <source>An unknown network-related error was detected</source>
        <translation>Um erro desconhecido relacionado à internet foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="241"/>
        <source>An unknown proxy-related error was detected</source>
        <translation>Um erro desconhecido relacionado ao proxy foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="243"/>
        <source>An unknown error related to the remote content was detected</source>
        <translation>Um erro desconhecido relacionado ao conteúdo remoto foi detectado</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="245"/>
        <source>A breakdown in protocol was detected</source>
        <translation>Uma pane no protocolo foi detectada</translation>
    </message>
    <message>
        <location filename="../base/net/downloadhandler.cpp" line="247"/>
        <source>Unknown error</source>
        <translation>Erro desconhecido</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="64"/>
        <location filename="../app/upgrade.h" line="77"/>
        <source>Upgrade</source>
        <translation>Upgrade</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="67"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. You will not be able to use an older version than v3.3.0 again. Continue? [y/n]</source>
        <translation>Você atualizou a partir de uma versão mais antiga que salvou as coisas de forma diferente. Você deve migrar para o novo sistema de salvamento. Você não será capaz de usar uma versão mais antiga que a v3.3.0 novamente. Continuar? [S/N]</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="76"/>
        <source>You updated from an older version that saved things differently. You must migrate to the new saving system. If you continue, you will not be able to use an older version than v3.3.0 again.</source>
        <translation>Você atualizou a partir de uma versão mais antiga que salvou as coisas de forma diferente. Você deve migrar para o novo sistema de salvamento. Se você continuar, não será capaz de usar uma versão mais antiga que a v3.3.0 novamente.</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="182"/>
        <source>Couldn&apos;t migrate torrent with hash: %1</source>
        <translation>Não foi possível migrar o torrent com hash: %1</translation>
    </message>
    <message>
        <location filename="../app/upgrade.h" line="185"/>
        <source>Couldn&apos;t migrate torrent. Invalid fastresume file name: %1</source>
        <translation>Não foi possível migrar o torrent. Nome inválido do arquivo de resumo rápido: %1</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="244"/>
        <source>Detected unclean program exit. Using fallback file to restore settings.</source>
        <translation>Detectado encerramento irregular do programa. Usando arquivo de reserva para restaurar as configurações.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="307"/>
        <source>An access error occurred while trying to write the configuration file.</source>
        <translation>Um erro de acesso ocorreu ao tentar escrever o arquivo de configuração.</translation>
    </message>
    <message>
        <location filename="../base/settingsstorage.cpp" line="309"/>
        <source>A format error occurred while trying to write the configuration file.</source>
        <translation>Um erro de formato ocorreu ao tentar escrever o arquivo de configuração.</translation>
    </message>
</context>
<context>
    <name>RSS::Private::Parser</name>
    <message>
        <location filename="../base/rss/private/rss_parser.cpp" line="264"/>
        <source>Invalid RSS feed.</source>
        <translation>Feed RSS inválido.</translation>
    </message>
</context>
<context>
    <name>RSS::Session</name>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="140"/>
        <source>RSS feed with given URL already exists: %1.</source>
        <translation>Feed RSS com o URL informado já existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="159"/>
        <source>Cannot move root folder.</source>
        <translation>Não é possível mover a pasta raiz.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="166"/>
        <location filename="../base/rss/rss_session.cpp" line="204"/>
        <source>Item doesn&apos;t exists: %1.</source>
        <translation>O item não existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="197"/>
        <source>Cannot delete root folder.</source>
        <translation>Não é possível excluir a pasta raiz.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="348"/>
        <source>Incorrect RSS Item path: %1.</source>
        <translation>Caminho incorreto do item RSS: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="354"/>
        <source>RSS item with given path already exists: %1.</source>
        <translation>O item RSS com o caminho fornecido já existe: %1.</translation>
    </message>
    <message>
        <location filename="../base/rss/rss_session.cpp" line="362"/>
        <source>Parent folder doesn&apos;t exist: %1.</source>
        <translation>A pasta pai não existe: %1.</translation>
    </message>
</context>
<context>
    <name>RSSWidget</name>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="17"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="31"/>
        <source>Fetching of RSS feeds is disabled now! You can enable it in application settings.</source>
        <translation>A procura de feeds RSS está desativada agora! Você pode ativá-la nas configurações do programa.</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="43"/>
        <source>New subscription</source>
        <translation>Nova inscrição</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="50"/>
        <location filename="../gui/rss/rsswidget.ui" line="174"/>
        <location filename="../gui/rss/rsswidget.ui" line="177"/>
        <source>Mark items read</source>
        <translation>Marcar itens como lidos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="57"/>
        <source>Refresh RSS streams</source>
        <translation>Atualizar streams RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="60"/>
        <source>Update all</source>
        <translation>Atualizar todos</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="80"/>
        <source>RSS Downloader...</source>
        <translation>Baixador RSS...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="108"/>
        <source>Torrents: (double-click to download)</source>
        <translation>Torrents: (duplo clique para baixar)</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="137"/>
        <location filename="../gui/rss/rsswidget.ui" line="140"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="145"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="148"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="153"/>
        <location filename="../gui/rss/rsswidget.ui" line="156"/>
        <source>Update</source>
        <translation>Atualizar</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="161"/>
        <source>New subscription...</source>
        <translation>Nova inscrição...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="166"/>
        <location filename="../gui/rss/rsswidget.ui" line="169"/>
        <source>Update all feeds</source>
        <translation>Atualizar todos os feeds</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="182"/>
        <source>Download torrent</source>
        <translation>Baixar torrent</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="187"/>
        <source>Open news URL</source>
        <translation>Abrir novas URL</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="192"/>
        <source>Copy feed URL</source>
        <translation>Copiar URL do feed</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.ui" line="197"/>
        <source>New folder...</source>
        <translation>Nova pasta...</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="213"/>
        <source>Please choose a folder name</source>
        <translation>Por favor escolha um nome de pasta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="213"/>
        <source>Folder name:</source>
        <translation>Nome da pasta:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="214"/>
        <source>New folder</source>
        <translation>Nova pasta</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="254"/>
        <source>Please type a RSS feed URL</source>
        <translation>Por favor, digite uma URL de feed RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="254"/>
        <source>Feed URL:</source>
        <translation>URL do feed:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="295"/>
        <source>Deletion confirmation</source>
        <translation>Confirmação de exclusão</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="295"/>
        <source>Are you sure you want to delete the selected RSS feeds?</source>
        <translation>Tem certeza de que deseja excluir os feeds RSS selecionados?</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="384"/>
        <source>Please choose a new name for this RSS feed</source>
        <translation>Por favor escolha um novo nome para este feed RSS</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="384"/>
        <source>New feed name:</source>
        <translation>Novo nome do feed:</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="391"/>
        <source>Rename failed</source>
        <translation>Falha ao renomear</translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="454"/>
        <source>Date: </source>
        <translation>Data: </translation>
    </message>
    <message>
        <location filename="../gui/rss/rsswidget.cpp" line="456"/>
        <source>Author: </source>
        <translation>Autor: </translation>
    </message>
</context>
<context>
    <name>ScanFoldersDelegate</name>
    <message>
        <location filename="../gui/scanfoldersdelegate.cpp" line="102"/>
        <source>Select save location</source>
        <translation>Selecione o local para salvar</translation>
    </message>
</context>
<context>
    <name>ScanFoldersModel</name>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="151"/>
        <source>Monitored Folder</source>
        <translation>Pasta Monitorada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="154"/>
        <source>Override Save Location</source>
        <translation>Substituir Local para Salvar</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="395"/>
        <source>Monitored folder</source>
        <translation>Pasta monitorada</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="397"/>
        <source>Default save location</source>
        <translation>Local padrão para salvar</translation>
    </message>
    <message>
        <location filename="../base/scanfoldersmodel.cpp" line="399"/>
        <source>Browse...</source>
        <translation>Procurar...</translation>
    </message>
</context>
<context>
    <name>SearchEngine</name>
    <message>
        <location filename="../base/searchengine.cpp" line="177"/>
        <source>Unknown search engine plugin file format.</source>
        <translation>Formato desconhecido do arquivo de plugin do motor de busca.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="191"/>
        <source>A more recent version of this plugin is already installed.</source>
        <translation>Uma versão mais recente de plugin de busca já está instalado.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="219"/>
        <location filename="../base/searchengine.cpp" line="222"/>
        <source>Plugin is not supported.</source>
        <translation>Plugin não suportado.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="376"/>
        <source>Update server is temporarily unavailable. %1</source>
        <translation>O servidor de atualizações está temporariamente indisponível. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="394"/>
        <location filename="../base/searchengine.cpp" line="396"/>
        <source>Failed to download the plugin file. %1</source>
        <translation>Falha ao baixar arquivo do plugin. %1</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="625"/>
        <source>An incorrect update info received.</source>
        <translation>Recebida uma informação incorreta de atualização.</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="649"/>
        <source>All categories</source>
        <translation>Todas as categorias</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="650"/>
        <source>Movies</source>
        <translation>Filmes</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="651"/>
        <source>TV shows</source>
        <translation>Shows de TV</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="652"/>
        <source>Music</source>
        <translation>Música</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="653"/>
        <source>Games</source>
        <translation>Jogos</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="654"/>
        <source>Anime</source>
        <translation>Anime</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="655"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="656"/>
        <source>Pictures</source>
        <translation>Imagens</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="657"/>
        <source>Books</source>
        <translation>Livros</translation>
    </message>
    <message>
        <location filename="../base/searchengine.cpp" line="682"/>
        <source>Search plugin &apos;%1&apos; contains invalid version string (&apos;%2&apos;)</source>
        <translation>O plugin de busca &apos;%1&apos; contém uma string de versão inválida (&apos;%2&apos;)</translation>
    </message>
</context>
<context>
    <name>SearchListDelegate</name>
    <message>
        <location filename="../gui/search/searchlistdelegate.cpp" line="60"/>
        <source>Unknown</source>
        <translation>Desconhecido</translation>
    </message>
</context>
<context>
    <name>SearchTab</name>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="74"/>
        <source>Name</source>
        <comment>i.e: file name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="75"/>
        <source>Size</source>
        <comment>i.e: file size</comment>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="76"/>
        <source>Seeders</source>
        <comment>i.e: Number of full sources</comment>
        <translation>Compartilhadores completos</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="77"/>
        <source>Leechers</source>
        <comment>i.e: Number of partial sources</comment>
        <translation>Compartilhadores parciais</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="78"/>
        <source>Search engine</source>
        <translation>Mecanismo de busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="204"/>
        <source>Results (showing &lt;i&gt;%1&lt;/i&gt; out of &lt;i&gt;%2&lt;/i&gt;):</source>
        <comment>i.e: Search results</comment>
        <translation>Resultados (exibindo &lt;i&gt;%1&lt;/i&gt; de &lt;i&gt;%2&lt;/i&gt;):</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="250"/>
        <source>Torrent names only</source>
        <translation>Somente nomes de torrents</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="251"/>
        <source>Everywhere</source>
        <translation>Em todos os lugares</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="262"/>
        <source>Searching...</source>
        <translation>Pesquisando...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="264"/>
        <source>Search has finished</source>
        <translation>Pesquisa concluída</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="266"/>
        <source>Search aborted</source>
        <translation>Pesquisa cancelada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="268"/>
        <source>An error occurred during search...</source>
        <translation>Ocorreu um erro durante a pesquisa...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="270"/>
        <source>Search returned no results</source>
        <translation>A pesquisa não retornou resultados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.cpp" line="312"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="22"/>
        <source>Results(xxx)</source>
        <translation>Resultados (xxx)</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="45"/>
        <source>Search in:</source>
        <translation>Pesquisar em:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Some search engines search in torrent description and in torrent file names too. Whether such results will be shown in the list below is controlled by this mode.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Everywhere &lt;/span&gt;disables filtering and shows everyhing returned by the search engines.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Torrent names only&lt;/span&gt; shows only torrents whose names match the search query.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Alguns mecanismos de pesquisa buscam na descrição do torrent e nos nomes de arquivos torrent também.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Em todos os lugares &lt;/span&gt;desativa a filtragem a exibe todos os resultados fornecidos pelos mecanismos de pesquisa.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Somente nomes de torrents&lt;/span&gt; exibe somente torrents cujos nomes correspondam ao termo pesquisado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed number of seeders&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Defina o número máximo e mínimo de seeders permitidos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="87"/>
        <source>Seeds:</source>
        <translation>Seeds:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número mínimo de seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="116"/>
        <location filename="../gui/search/searchtab.ui" line="204"/>
        <source>to</source>
        <translation>até</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="123"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal number of seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Número máximo de seeds&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/search/searchtab.ui" line="126"/>
        <location filename="../gui/search/searchtab.ui" line="216"/>
        <source>∞</source>
        <translation>∞</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="167"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set minimal and maximal allowed size of a torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Defina o tamanho máximo e mínimo permitido do torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="170"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="179"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamanho mínimo do torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchtab.ui" line="213"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Maximal torrent size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamanho máximo do torrent&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SearchWidget</name>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="14"/>
        <location filename="../gui/search/searchwidget.ui" line="51"/>
        <location filename="../gui/search/searchwidget.cpp" line="265"/>
        <location filename="../gui/search/searchwidget.cpp" line="291"/>
        <location filename="../gui/search/searchwidget.cpp" line="358"/>
        <source>Search</source>
        <translation>Busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="79"/>
        <source>There aren&apos;t any search plugins installed.
Click the &quot;Search plugins...&quot; button at the bottom right of the window to install some.</source>
        <translation>Nenhum plugin de busca está instalado.
Clique no botão &quot;Plugins de busca&quot; na parte inferior direita da janela para instalar alguns.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="122"/>
        <source>Download</source>
        <translation>Download</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="132"/>
        <source>Go to description page</source>
        <translation>Ir para a página de descrição</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="142"/>
        <source>Copy description page URL</source>
        <translation>Copiar URL da página de descrição</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.ui" line="162"/>
        <source>Search plugins...</source>
        <translation>Plugins de busca...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="87"/>
        <source>A phrase to search for.</source>
        <translation>Uma frase para ser pesquisada.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="88"/>
        <source>Spaces in a search term may be protected by double quotes.</source>
        <translation>Espaços em um termo de pesquisa devem ser protegidos por aspas duplas.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="90"/>
        <source>Example:</source>
        <comment>Search phrase example</comment>
        <translation>Exemplo:</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="92"/>
        <source>&lt;b&gt;foo bar&lt;/b&gt;: search for &lt;b&gt;foo&lt;/b&gt; and &lt;b&gt;bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, a pair of space delimited words, individal words are highlighted</comment>
        <translation>&lt;b&gt;foo bar&lt;/b&gt;: pesquise por &lt;b&gt;foo&lt;/b&gt; e &lt;b&gt;bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="96"/>
        <source>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: search for &lt;b&gt;foo bar&lt;/b&gt;</source>
        <comment>Search phrase example, illustrates quotes usage, double quotedpair of space delimited words, the whole pair is highlighted</comment>
        <translation>&lt;b&gt;&amp;quot;foo bar&amp;quot;&lt;/b&gt;: pesquise por &lt;b&gt;foo bar&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="165"/>
        <source>All plugins</source>
        <translation>Todos os plugins</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="164"/>
        <source>Only enabled</source>
        <translation>Somente habilitados</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="166"/>
        <source>Select...</source>
        <translation>Selecionar...</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <location filename="../gui/search/searchwidget.cpp" line="346"/>
        <location filename="../gui/search/searchwidget.cpp" line="364"/>
        <source>Search Engine</source>
        <translation>Mecanismo de Busca</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="283"/>
        <source>Please install Python to use the Search Engine.</source>
        <translation>Por favor, instale o Python para usar o Mecanismo de Busca.</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="301"/>
        <source>Empty search pattern</source>
        <translation>Padrão de busca vazio</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="301"/>
        <source>Please type a search pattern first</source>
        <translation>Por favor digite um padrão de busca primeiro</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="337"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="346"/>
        <source>Search has finished</source>
        <translation>Busca finalizada</translation>
    </message>
    <message>
        <location filename="../gui/search/searchwidget.cpp" line="364"/>
        <source>Search has failed</source>
        <translation>Busca falhou</translation>
    </message>
</context>
<context>
    <name>ShutdownConfirmDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="110"/>
        <source>qBittorrent will now exit.</source>
        <translation>O qBittorrent irá sair agora.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="111"/>
        <source>E&amp;xit Now</source>
        <translation>Sair A&amp;gora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="112"/>
        <source>Exit confirmation</source>
        <translation>Confirmação de saída</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="115"/>
        <source>The computer is going to shutdown.</source>
        <translation>O computador será desligado.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="116"/>
        <source>&amp;Shutdown Now</source>
        <translation>&amp;Desligar Agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="120"/>
        <source>The computer is going to enter suspend mode.</source>
        <translation>O computador será colocado em modo de suspensão.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="121"/>
        <source>&amp;Suspend Now</source>
        <translation>&amp;Suspender Agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="122"/>
        <source>Suspend confirmation</source>
        <translation>Confirmar suspensão</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="125"/>
        <source>The computer is going to enter hibernation mode.</source>
        <translation>O computador entrará em modo de hibernação.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="126"/>
        <source>&amp;Hibernate Now</source>
        <translation>&amp;Hibernar Agora</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="127"/>
        <source>Hibernate confirmation</source>
        <translation>Confirmar hibernação</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="137"/>
        <source>You can cancel the action within %1 seconds.</source>
        <translation>Você pode cancelar a ação dentro de %1 segundos.</translation>
    </message>
    <message>
        <location filename="../gui/shutdownconfirmdlg.cpp" line="117"/>
        <source>Shutdown confirmation</source>
        <translation>Confirmação de desligamento</translation>
    </message>
</context>
<context>
    <name>SpeedLimitDialog</name>
    <message>
        <location filename="../gui/speedlimitdlg.cpp" line="81"/>
        <source>KiB/s</source>
        <translation>KiB/s</translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="52"/>
        <source>Total Upload</source>
        <translation>Upload Total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="53"/>
        <source>Total Download</source>
        <translation>Download Total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="57"/>
        <source>Payload Upload</source>
        <translation>Upload Payload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="58"/>
        <source>Payload Download</source>
        <translation>Download Payload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="62"/>
        <source>Overhead Upload</source>
        <translation>Sobrecarga de Upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="63"/>
        <source>Overhead Download</source>
        <translation>Sobrecarga de Download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="67"/>
        <source>DHT Upload</source>
        <translation>Upload DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="68"/>
        <source>DHT Download</source>
        <translation>Download DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="72"/>
        <source>Tracker Upload</source>
        <translation>Upload do Tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedplotview.cpp" line="73"/>
        <source>Tracker Download</source>
        <translation>Download do Tracker</translation>
    </message>
</context>
<context>
    <name>SpeedWidget</name>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="68"/>
        <source>Period:</source>
        <translation>Período:</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="71"/>
        <source>1 Minute</source>
        <translation>1 minuto</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="72"/>
        <source>5 Minutes</source>
        <translation>5 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="73"/>
        <source>30 Minutes</source>
        <translation>30 minutos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="74"/>
        <source>6 Hours</source>
        <translation>6 horas</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="106"/>
        <source>Select Graphs</source>
        <translation>Selecione os Gráficos</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="80"/>
        <source>Total Upload</source>
        <translation>Upload Total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="81"/>
        <source>Total Download</source>
        <translation>Download Total</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="82"/>
        <source>Payload Upload</source>
        <translation>Upload Payload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="83"/>
        <source>Payload Download</source>
        <translation>Download Payload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="84"/>
        <source>Overhead Upload</source>
        <translation>Sobrecarga de Upload</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="85"/>
        <source>Overhead Download</source>
        <translation>Sobrecarga de Download</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="86"/>
        <source>DHT Upload</source>
        <translation>Upload DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="87"/>
        <source>DHT Download</source>
        <translation>Download DHT</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="88"/>
        <source>Tracker Upload</source>
        <translation>Upload do Tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/speedwidget.cpp" line="89"/>
        <source>Tracker Download</source>
        <translation>Download do Tracker</translation>
    </message>
</context>
<context>
    <name>StatsDialog</name>
    <message>
        <location filename="../gui/statsdialog.ui" line="14"/>
        <source>Statistics</source>
        <translation>Estatísticas</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="20"/>
        <source>User statistics</source>
        <translation>Estatísticas de usuário</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="26"/>
        <source>Total peer connections:</source>
        <translation>Total de conexões de peer:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="33"/>
        <source>Global ratio:</source>
        <translation>Proporção global:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="47"/>
        <source>Alltime download:</source>
        <translation>Download (desde sempre):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="68"/>
        <source>Alltime upload:</source>
        <translation>Upload (desde sempre):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="82"/>
        <source>Total waste (this session):</source>
        <translation>Total desperdiçado (nesta sessão):</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="99"/>
        <source>Cache statistics</source>
        <translation>Estatísticas de cache</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="105"/>
        <source>Read cache hits:</source>
        <translation>Acertos do cache de leitura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="184"/>
        <source>Average time in queue:</source>
        <translation>Tempo médio na fila:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="126"/>
        <source>Total buffers size:</source>
        <translation>Tamanho total dos buffers:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="136"/>
        <source>Performance statistics</source>
        <translation>Estatísticas de performance</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="170"/>
        <source>Queued I/O jobs:</source>
        <translation>Trabalhos de E/S na fila:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="177"/>
        <source>Write cache overload:</source>
        <translation>Sobrecarga do cache de escrita:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="191"/>
        <source>Read cache overload:</source>
        <translation>Sobrecarga do cache de leitura:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.ui" line="198"/>
        <source>Total queued size:</source>
        <translation>Tamanho total em fila:</translation>
    </message>
    <message>
        <location filename="../gui/statsdialog.cpp" line="100"/>
        <source>%1 ms</source>
        <comment>18 milliseconds</comment>
        <translation>%1 ms</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <location filename="../gui/statusbar.cpp" line="68"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>Connection status:</source>
        <translation>Estado da conexão:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="69"/>
        <location filename="../gui/statusbar.cpp" line="188"/>
        <source>No direct connections. This may indicate network configuration problems.</source>
        <translation>Sem conexões diretas. Talvez tenha algo errado em sua configuração.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="90"/>
        <location filename="../gui/statusbar.cpp" line="197"/>
        <source>DHT: %1 nodes</source>
        <translation>DHT: %1 nos</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="161"/>
        <source>qBittorrent needs to be restarted!</source>
        <translation>O qBittorrent precisa ser reiniciado!</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Connection Status:</source>
        <translation>Estado da conexão:</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="178"/>
        <source>Offline. This usually means that qBittorrent failed to listen on the selected port for incoming connections.</source>
        <translation>Offline. Isto acontece quando o qBittorrent falha para escutar na porta selecionada para conexões de entrada.</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="184"/>
        <source>Online</source>
        <translation>Online</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="239"/>
        <source>Click to switch to alternative speed limits</source>
        <translation>Clique aqui para mudar para os limites de velocidade alternativa</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="234"/>
        <source>Click to switch to regular speed limits</source>
        <translation>Clique aqui para alternar para regular os limites de velocidade</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="251"/>
        <source>Global Download Speed Limit</source>
        <translation>Limite de Velocidade Global de Download</translation>
    </message>
    <message>
        <location filename="../gui/statusbar.cpp" line="265"/>
        <source>Global Upload Speed Limit</source>
        <translation>Limite de Velocidade Global de Upload</translation>
    </message>
</context>
<context>
    <name>StatusFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="124"/>
        <source>All (0)</source>
        <comment>this is for the status filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="127"/>
        <source>Downloading (0)</source>
        <translation>Baixando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="130"/>
        <source>Seeding (0)</source>
        <translation>Enviando (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="133"/>
        <source>Completed (0)</source>
        <translation>Completo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="136"/>
        <source>Resumed (0)</source>
        <translation>Retomado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="139"/>
        <source>Paused (0)</source>
        <translation>Pausado (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="142"/>
        <source>Active (0)</source>
        <translation>Ativo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="145"/>
        <source>Inactive (0)</source>
        <translation>Inativo (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="148"/>
        <source>Errored (0)</source>
        <translation>Com erro (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="165"/>
        <source>All (%1)</source>
        <translation>Todos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="166"/>
        <source>Downloading (%1)</source>
        <translation>Baixando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="167"/>
        <source>Seeding (%1)</source>
        <translation>Enviando (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="168"/>
        <source>Completed (%1)</source>
        <translation>Completo (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="169"/>
        <source>Paused (%1)</source>
        <translation>Pausado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="170"/>
        <source>Resumed (%1)</source>
        <translation>Retomado (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="171"/>
        <source>Active (%1)</source>
        <translation>Ativos (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="172"/>
        <source>Inactive (%1)</source>
        <translation>Inativo (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="173"/>
        <source>Errored (%1)</source>
        <translation>Com erro (%1)</translation>
    </message>
</context>
<context>
    <name>TagFilterModel</name>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="147"/>
        <source>Tags</source>
        <translation>Tags</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="258"/>
        <source>All</source>
        <translation>Tudo</translation>
    </message>
    <message>
        <location filename="../gui/tagfiltermodel.cpp" line="260"/>
        <source>Untagged</source>
        <translation>Sem etiqueta</translation>
    </message>
</context>
<context>
    <name>TagFilterWidget</name>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="113"/>
        <source>Add tag...</source>
        <translation>Adicionar tag...</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="120"/>
        <source>Remove tag</source>
        <translation>Remover tag</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="126"/>
        <source>Remove unused tags</source>
        <translation>Remover tags não utilizadas</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="133"/>
        <source>Resume torrents</source>
        <translation>Retomar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="139"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="145"/>
        <source>Delete torrents</source>
        <translation>Apagar torrents</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>New Tag</source>
        <translation>Nova tag</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="188"/>
        <source>Tag:</source>
        <translation>Tag:</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="192"/>
        <source>Invalid tag name</source>
        <translation>Nome de tag inválido</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="193"/>
        <source>Tag name &apos;%1&apos; is invalid</source>
        <translation>O nome de tag &apos;%1&apos; é inválido</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag exists</source>
        <translation>A tag existe</translation>
    </message>
    <message>
        <location filename="../gui/tagfilterwidget.cpp" line="208"/>
        <source>Tag name already exists.</source>
        <translation>O nome de tag já existe.</translation>
    </message>
</context>
<context>
    <name>TorrentCategoryDialog</name>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="14"/>
        <source>Torrent Category Properties</source>
        <translation>Propriedades da Categoria do Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.ui" line="45"/>
        <source>Save path:</source>
        <translation>Caminho para salvar:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="58"/>
        <source>New Category</source>
        <translation>Nova Categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="67"/>
        <source>Invalid category name</source>
        <translation>Nome de categoria inválido</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="68"/>
        <source>Category name cannot contain &apos;\&apos;.
Category name cannot start/end with &apos;/&apos;.
Category name cannot contain &apos;//&apos; sequence.</source>
        <translation>O nome da categoria não pode conter &apos;\&apos;.
O nome da categoria não pode iniciar/terminar com &apos;/&apos;.
O nome da categoria não pode conter a sequência &apos;//&apos;.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="74"/>
        <source>Category creation error</source>
        <translation>Erro ao criar categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentcategorydialog.cpp" line="75"/>
        <source>Category with the given name already exists.
Please choose a different name and try again.</source>
        <translation>Uma categoria com este nome já existe.
Por favor, escolha um nome diferente e tente novamente.</translation>
    </message>
</context>
<context>
    <name>TorrentContentModel</name>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Download Priority</source>
        <translation>Prioridade de download</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Remaining</source>
        <translation>Faltando</translation>
    </message>
    <message>
        <location filename="../gui/torrentcontentmodel.cpp" line="205"/>
        <source>Availability</source>
        <translation>Disponibilidade</translation>
    </message>
</context>
<context>
    <name>TorrentCreatorDlg</name>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="68"/>
        <source>Create Torrent</source>
        <translation>Criar torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="149"/>
        <source>Reason: Path to file/folder is not readable.</source>
        <translation>Motivo: O caminho para o arquivo/ pasta não possui suporte para leitura.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="149"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="179"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="191"/>
        <source>Torrent creation failed</source>
        <translation>Falha na criação do torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="156"/>
        <source>Torrent Files (*.torrent)</source>
        <translation>Arquivos torrent (*.torrent)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="156"/>
        <source>Select where to save the new torrent</source>
        <translation>Selecione onde salvar o novo torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="179"/>
        <source>Reason: %1</source>
        <translation>Motivo: %1</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="191"/>
        <source>Reason: Created torrent is invalid. It won&apos;t be added to download list.</source>
        <translation>Motivo: O torrent criado é inválido. Não será adicionado à lista de downloads.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="202"/>
        <source>Torrent creator</source>
        <translation>Criar torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.cpp" line="202"/>
        <source>Torrent created:</source>
        <translation>Torrent criado:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="17"/>
        <source>Torrent Creator</source>
        <translation>Criar Torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="23"/>
        <source>Select file/folder to share</source>
        <translation>Selecione o arquivo/pasta para compartilhar</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="31"/>
        <source>Path:</source>
        <translation>Caminho:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="58"/>
        <source>[Drag and drop area]</source>
        <translation>[Área para arrastar e soltar]</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="68"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="112"/>
        <source>Select file</source>
        <translation>Selecione o arquivo</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="75"/>
        <location filename="../gui/torrentcreatordlg.cpp" line="105"/>
        <source>Select folder</source>
        <translation>Selecione a pasta</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="87"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="95"/>
        <source>Piece size:</source>
        <translation>Tamanho da parte:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="109"/>
        <source>Auto</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="114"/>
        <source>16 KiB</source>
        <translation>16 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="119"/>
        <source>32 KiB</source>
        <translation>32 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="124"/>
        <source>64 KiB</source>
        <translation>64 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="129"/>
        <source>128 KiB</source>
        <translation>128 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="134"/>
        <source>256 KiB</source>
        <translation>256 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="139"/>
        <source>512 KiB</source>
        <translation>512 KiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="144"/>
        <source>1 MiB</source>
        <translation>1 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="149"/>
        <source>2 MiB</source>
        <translation>2 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="154"/>
        <source>4 MiB</source>
        <translation>4 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="159"/>
        <source>8 MiB</source>
        <translation>8 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="164"/>
        <source>16 MiB</source>
        <translation>16 MiB</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="172"/>
        <source>Calculate number of pieces:</source>
        <translation>Calcular número de partes:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="201"/>
        <source>Private torrent (Won&apos;t distribute on DHT network)</source>
        <translation>Torrent privado (não distribuir em redes DHT)</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="208"/>
        <source>Start seeding immediately</source>
        <translation>Inicar a compartilhar imediatamente</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="218"/>
        <source>Ignore share ratio limits for this torrent</source>
        <translation>Ignorar limites de compartilhamento para esse torrent</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="228"/>
        <source>Fields</source>
        <translation>Campos</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="234"/>
        <source>You can separate tracker tiers / groups with an empty line.</source>
        <comment>A tracker tier is a group of trackers, consisting of a main tracker and its mirrors.</comment>
        <translation>Você pode separar níveis / grupos de trackers com uma linha vazia.</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="244"/>
        <source>Web seed URLs:</source>
        <translation>URLs de seed web:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="265"/>
        <source>Tracker URLs:</source>
        <translation>URLs do Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="272"/>
        <source>Comments:</source>
        <translation>Comentários:</translation>
    </message>
    <message>
        <location filename="../gui/torrentcreatordlg.ui" line="284"/>
        <source>Progress:</source>
        <translation>Progresso:</translation>
    </message>
</context>
<context>
    <name>TorrentModel</name>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="97"/>
        <source>Name</source>
        <comment>i.e: torrent name</comment>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="98"/>
        <source>Size</source>
        <comment>i.e: torrent size</comment>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="99"/>
        <source>Done</source>
        <comment>% Done</comment>
        <translation>Feito</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="100"/>
        <source>Status</source>
        <comment>Torrent status (e.g. downloading, seeding, paused)</comment>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="101"/>
        <source>Seeds</source>
        <comment>i.e. full sources (often untranslated)</comment>
        <translation>Seeds</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="102"/>
        <source>Peers</source>
        <comment>i.e. partial sources (often untranslated)</comment>
        <translation>Peers</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="103"/>
        <source>Down Speed</source>
        <comment>i.e: Download speed</comment>
        <translation>Velocidade de download</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="104"/>
        <source>Up Speed</source>
        <comment>i.e: Upload speed</comment>
        <translation>Velocidade de upload</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="105"/>
        <source>Ratio</source>
        <comment>Share ratio</comment>
        <translation>Taxa</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="106"/>
        <source>ETA</source>
        <comment>i.e: Estimated Time of Arrival / Time left</comment>
        <translation>ETA</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="107"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="108"/>
        <source>Tags</source>
        <translation>Tags</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="109"/>
        <source>Added On</source>
        <comment>Torrent was added to transfer list on 01/01/2010 08:00</comment>
        <translation>Adicionado em</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="110"/>
        <source>Completed On</source>
        <comment>Torrent was completed on 01/01/2010 08:00</comment>
        <translation>Completado em</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="111"/>
        <source>Tracker</source>
        <translation>Tracker</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="112"/>
        <source>Down Limit</source>
        <comment>i.e: Download limit</comment>
        <translation>Limite de download</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="113"/>
        <source>Up Limit</source>
        <comment>i.e: Upload limit</comment>
        <translation>Limite de upload</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="114"/>
        <source>Downloaded</source>
        <comment>Amount of data downloaded (e.g. in MB)</comment>
        <translation>Recebido</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="115"/>
        <source>Uploaded</source>
        <comment>Amount of data uploaded (e.g. in MB)</comment>
        <translation>Enviado</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="116"/>
        <source>Session Download</source>
        <comment>Amount of data downloaded since program open (e.g. in MB)</comment>
        <translation>Baixado na sessão</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="117"/>
        <source>Session Upload</source>
        <comment>Amount of data uploaded since program open (e.g. in MB)</comment>
        <translation>Enviado na sessão</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="118"/>
        <source>Remaining</source>
        <comment>Amount of data left to download (e.g. in MB)</comment>
        <translation>Faltando</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="119"/>
        <source>Time Active</source>
        <comment>Time (duration) the torrent is active (not paused)</comment>
        <translation>Tempo Ativo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="120"/>
        <source>Save path</source>
        <comment>Torrent save path</comment>
        <translation>Caminho para salvar</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="121"/>
        <source>Completed</source>
        <comment>Amount of data completed (e.g. in MB)</comment>
        <translation>Completo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="122"/>
        <source>Ratio Limit</source>
        <comment>Upload share ratio limit</comment>
        <translation>Limite da proporção</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="123"/>
        <source>Last Seen Complete</source>
        <comment>Indicates the time when the torrent was last seen complete/whole</comment>
        <translation>Última Vez Visto Completo</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="124"/>
        <source>Last Activity</source>
        <comment>Time passed since a chunk was downloaded/uploaded</comment>
        <translation>Última Atividade</translation>
    </message>
    <message>
        <location filename="../gui/torrentmodel.cpp" line="125"/>
        <source>Total Size</source>
        <comment>i.e. Size including unwanted data</comment>
        <translation>Tamanho Total</translation>
    </message>
</context>
<context>
    <name>TrackerFiltersList</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="193"/>
        <source>All (0)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="196"/>
        <source>Trackerless (0)</source>
        <translation>Sem rastreador (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="199"/>
        <source>Error (0)</source>
        <translation>Erro (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="202"/>
        <source>Warning (0)</source>
        <translation>Aviso (0)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="246"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="301"/>
        <source>Trackerless (%1)</source>
        <translation>Sem rastreador (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="339"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="371"/>
        <source>Error (%1)</source>
        <translation>Erro (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="352"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="386"/>
        <source>Warning (%1)</source>
        <translation>Aviso (%1)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="446"/>
        <source>Resume torrents</source>
        <translation>Retomar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="447"/>
        <source>Pause torrents</source>
        <translation>Pausar torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="448"/>
        <source>Delete torrents</source>
        <translation>Apagar Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="482"/>
        <location filename="../gui/transferlistfilterswidget.cpp" line="496"/>
        <source>All (%1)</source>
        <comment>this is for the tracker filter</comment>
        <translation>Todos (%1)</translation>
    </message>
</context>
<context>
    <name>TrackerList</name>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="588"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="589"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="590"/>
        <source>Received</source>
        <translation>Recebido</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="591"/>
        <source>Seeds</source>
        <translation>Seeds</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="592"/>
        <source>Peers</source>
        <translation>Fontes</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="593"/>
        <source>Downloaded</source>
        <translation>Baixado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="594"/>
        <source>Message</source>
        <translation>Mensagem</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="255"/>
        <location filename="../gui/properties/trackerlist.cpp" line="345"/>
        <source>Working</source>
        <translation>Trabalhando</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="256"/>
        <source>Disabled</source>
        <translation>Desabilitado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="277"/>
        <source>This torrent is private</source>
        <translation>Este torrent é privado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="349"/>
        <source>Updating...</source>
        <translation>Atualizando...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="353"/>
        <source>Not working</source>
        <translation>Sem serviço</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="357"/>
        <source>Not contacted yet</source>
        <translation>Não contactado ainda</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="458"/>
        <source>Tracker URL:</source>
        <translation>Link do Tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="458"/>
        <source>Tracker editing</source>
        <translation>Editando Tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="463"/>
        <location filename="../gui/properties/trackerlist.cpp" line="473"/>
        <source>Tracker editing failed</source>
        <translation>Falha editando Tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="463"/>
        <source>The tracker URL entered is invalid.</source>
        <translation>O link do Tracker está inválido</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="473"/>
        <source>The tracker URL already exists.</source>
        <translation>O link do Tracker já existe.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="527"/>
        <source>Add a new tracker...</source>
        <translation>Adicionar novo tracker...</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="533"/>
        <source>Copy tracker URL</source>
        <translation>Copiar URL do tracker</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="534"/>
        <source>Edit selected tracker URL</source>
        <translation>Editar link do Tracker selecionado</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="539"/>
        <source>Force reannounce to selected trackers</source>
        <translation>Forçar reanúncio para os trackers selecionados</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="541"/>
        <source>Force reannounce to all trackers</source>
        <translation>Forçar reanuncio de todos os trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="614"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackerlist.cpp" line="532"/>
        <source>Remove tracker</source>
        <translation>Remover tracker</translation>
    </message>
</context>
<context>
    <name>TrackersAdditionDlg</name>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="14"/>
        <source>Trackers addition dialog</source>
        <translation>Diálogo de adição de Trackers</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.ui" line="20"/>
        <source>List of trackers to add (one per line):</source>
        <translation>Lista Trackers para adicionar (um por linha):</translation>
    </message>
    <message utf8="true">
        <location filename="../gui/properties/trackersadditiondlg.ui" line="37"/>
        <source>µTorrent compatible list URL:</source>
        <translation>URL da lista compatível com µTorrent:</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="86"/>
        <source>I/O Error</source>
        <translation>Erro de entrada e saída</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="86"/>
        <source>Error while trying to open the downloaded file.</source>
        <translation>Erro ao tentar abrir o arquivo baixado.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="124"/>
        <source>No change</source>
        <translation>Sem mudanças</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="124"/>
        <source>No additional trackers were found.</source>
        <translation>Não foram encontrados Trackers adicionais.</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="132"/>
        <source>Download error</source>
        <translation>Erro no download</translation>
    </message>
    <message>
        <location filename="../gui/properties/trackersadditiondlg.cpp" line="132"/>
        <source>The trackers list could not be downloaded, reason: %1</source>
        <translation>A lista de trackers não pode ser baixada, razão: %1</translation>
    </message>
</context>
<context>
    <name>TransferListDelegate</name>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="232"/>
        <source>Downloading</source>
        <translation>Baixando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="238"/>
        <source>Downloading metadata</source>
        <comment>used when loading a magnet link</comment>
        <translation>Baixando metadata</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="244"/>
        <source>Allocating</source>
        <comment>qBittorrent is allocating the files on disk</comment>
        <translation>Alocando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="270"/>
        <source>Paused</source>
        <translation>Pausado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="255"/>
        <source>Queued</source>
        <comment>i.e. torrent is queued</comment>
        <translation>Espera</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="248"/>
        <source>Seeding</source>
        <comment>Torrent is complete and in upload-only mode</comment>
        <translation>Enviando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="235"/>
        <source>Stalled</source>
        <comment>Torrent is waiting for download to begin</comment>
        <translation>Estacionado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="241"/>
        <source>[F] Downloading</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Baixando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="251"/>
        <source>[F] Seeding</source>
        <comment>used when the torrent is forced started. You probably shouldn&apos;t translate the F.</comment>
        <translation>[F] Enviando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="259"/>
        <source>Checking</source>
        <comment>Torrent local data is being checked</comment>
        <translation>Checando</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="263"/>
        <source>Queued for checking</source>
        <comment>i.e. torrent is queued for hash checking</comment>
        <translation>Na fila de verificação</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="267"/>
        <source>Checking resume data</source>
        <comment>used when loading the torrents from disk after qbt is launched. It checks the correctness of the .fastresume file. Normally it is completed in a fraction of a second, unless loading many many torrents.</comment>
        <translation>Verificando dados de resumo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="273"/>
        <source>Completed</source>
        <translation>Completo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="276"/>
        <source>Missing Files</source>
        <translation>Arquivos indisponíveis</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="279"/>
        <source>Errored</source>
        <comment>torrent status, the torrent has an error</comment>
        <translation>Com erro</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="128"/>
        <source>%1 (seeded for %2)</source>
        <comment>e.g. 4m39s (seeded for 3m10s)</comment>
        <translation>%1 (semeado por %2)</translation>
    </message>
    <message>
        <location filename="../gui/transferlistdelegate.cpp" line="189"/>
        <source>%1 ago</source>
        <comment>e.g.: 1h 20m ago</comment>
        <translation>%1 atrás</translation>
    </message>
</context>
<context>
    <name>TransferListFiltersWidget</name>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="576"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="584"/>
        <source>Categories</source>
        <translation>Categorias</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="603"/>
        <source>Tags</source>
        <translation>Tags</translation>
    </message>
    <message>
        <location filename="../gui/transferlistfilterswidget.cpp" line="621"/>
        <source>Trackers</source>
        <translation>Trackers</translation>
    </message>
</context>
<context>
    <name>TransferListWidget</name>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="672"/>
        <source>Column visibility</source>
        <translation>Visibilidade da coluna</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="386"/>
        <source>Choose save path</source>
        <translation>Escolha caminho de salvamento</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="591"/>
        <source>Torrent Download Speed Limiting</source>
        <translation>Limitando Velocidade de Download de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="616"/>
        <source>Torrent Upload Speed Limiting</source>
        <translation>Limitando Velocidade de Upload de Torrent</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="660"/>
        <source>Recheck confirmation</source>
        <translation>Confirmação de rechecagem</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="660"/>
        <source>Are you sure you want to recheck the selected torrent(s)?</source>
        <translation>Tem certeza de que deseja checar novamente o(s) torrent(s) selecionado(s)?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="802"/>
        <source>Rename</source>
        <translation>Renomear</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="802"/>
        <source>New name:</source>
        <translation>Novo nome:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="837"/>
        <source>Resume</source>
        <comment>Resume/start the torrent</comment>
        <translation>Resumir</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="841"/>
        <source>Force Resume</source>
        <comment>Force Resume/start the torrent</comment>
        <translation>Forçar retomada</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="839"/>
        <source>Pause</source>
        <comment>Pause the torrent</comment>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="393"/>
        <source>Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <comment>Set location: moving &quot;ubuntu_16_04.iso&quot;, from &quot;/home/dir1&quot; to &quot;/home/dir2&quot;</comment>
        <translation>Definir local: movendo &quot;%1&quot;, de &quot;%2&quot; para &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="744"/>
        <source>Add Tags</source>
        <translation>Adicionar tags</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="752"/>
        <source>Remove All Tags</source>
        <translation>Remover todas as tags</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="752"/>
        <source>Remove all tags from selected torrents?</source>
        <translation>Remover todas as tags dos torrents selecionados?</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="766"/>
        <source>Comma-separated tags:</source>
        <translation>Tags separadas por vírgulas:</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="773"/>
        <source>Invalid tag</source>
        <translation>Tag inválida</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="774"/>
        <source>Tag name: &apos;%1&apos; is invalid</source>
        <translation>O nome de tag: &apos;%1&apos; é inválido</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="843"/>
        <source>Delete</source>
        <comment>Delete the torrent</comment>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="845"/>
        <source>Preview file...</source>
        <translation>Arquivo de pré-exibição...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="847"/>
        <source>Limit share ratio...</source>
        <translation>Taxa de limite de compartilhamento...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="849"/>
        <source>Limit upload rate...</source>
        <translation>Limite de taxa de upload...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="851"/>
        <source>Limit download rate...</source>
        <translation>Limite de taxa de download...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="853"/>
        <source>Open destination folder</source>
        <translation>Abrir pasta de destino</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="855"/>
        <source>Move up</source>
        <comment>i.e. move up in the queue</comment>
        <translation>Mover para cima</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="857"/>
        <source>Move down</source>
        <comment>i.e. Move down in the queue</comment>
        <translation>Mover para baixo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="859"/>
        <source>Move to top</source>
        <comment>i.e. Move to top of the queue</comment>
        <translation>Mover para o topo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="861"/>
        <source>Move to bottom</source>
        <comment>i.e. Move to bottom of the queue</comment>
        <translation>Mover para último</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="863"/>
        <source>Set location...</source>
        <translation>Definir local...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="869"/>
        <source>Copy name</source>
        <translation>Copiar nome</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="871"/>
        <source>Copy hash</source>
        <translation>Copiar hash</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="881"/>
        <source>Download first and last pieces first</source>
        <translation>Baixar primeiro a primeira e a última parte</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="884"/>
        <source>Automatic Torrent Management</source>
        <translation>Gerenciamento Automático de Torrents</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="886"/>
        <source>Automatic mode means that various torrent properties(eg save path) will be decided by the associated category</source>
        <translation>O modo automático configura várias propriedades do torrent (ex.: caminho para salvar) baseado na categoria associada</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="993"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="994"/>
        <source>New...</source>
        <comment>New category...</comment>
        <translation>Nova...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="995"/>
        <source>Reset</source>
        <comment>Reset category</comment>
        <translation>Resetar</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1012"/>
        <source>Tags</source>
        <translation>Tags</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1013"/>
        <source>Add...</source>
        <comment>Add / assign multiple tags...</comment>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1014"/>
        <source>Remove All</source>
        <comment>Remove all tags</comment>
        <translation>Remover tudo</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="1075"/>
        <source>Priority</source>
        <translation>Prioridade</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="865"/>
        <source>Force recheck</source>
        <translation>Forçar re-checagem</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="867"/>
        <source>Copy magnet link</source>
        <translation>Copiar link magnético</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="873"/>
        <source>Super seeding mode</source>
        <translation>Modo super compartilhador</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="876"/>
        <source>Rename...</source>
        <translation>Renomear...</translation>
    </message>
    <message>
        <location filename="../gui/transferlistwidget.cpp" line="878"/>
        <source>Download in sequential order</source>
        <translation>Download em ordem sequencial</translation>
    </message>
</context>
<context>
    <name>UpDownRatioDlg</name>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="14"/>
        <source>Torrent Upload/Download Ratio Limiting</source>
        <translation>Torrent Upload/Download limite</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="20"/>
        <source>Use global share limit</source>
        <translation>Usar limite global de compartilhamento</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="30"/>
        <source>Set no share limit</source>
        <translation>Não definir limite de compartilhamento</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="42"/>
        <source>Set share limit to</source>
        <translation>Definir limite de compartilhamento para</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="100"/>
        <source>ratio</source>
        <translation>taxa</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="107"/>
        <source>minutes</source>
        <translation>minutos</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.ui" line="23"/>
        <location filename="../gui/updownratiodlg.ui" line="33"/>
        <location filename="../gui/updownratiodlg.ui" line="45"/>
        <source>buttonGroup</source>
        <translation>botãoGrupo</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.cpp" line="81"/>
        <source>No share limit method selected</source>
        <translation>Nenhum método de limite de compartilhamento selecionado</translation>
    </message>
    <message>
        <location filename="../gui/updownratiodlg.cpp" line="82"/>
        <source>Please select a limit method first</source>
        <translation>Por favor, selecione primeiro um método de limitação</translation>
    </message>
</context>
<context>
    <name>WebApplication</name>
    <message>
        <location filename="../webui/webapplication.cpp" line="834"/>
        <source>WebUI Set location: moving &quot;%1&quot;, from &quot;%2&quot; to &quot;%3&quot;</source>
        <translation>Interface Web - Definir local: movendo &quot;%1&quot;, de &quot;%2&quot; para &quot;%3&quot;</translation>
    </message>
    <message>
        <location filename="../webui/webapplication.cpp" line="911"/>
        <source>Incorrect category name</source>
        <translation>Nome incorreto da categoria</translation>
    </message>
</context>
<context>
    <name>WebUI</name>
    <message>
        <location filename="../webui/webui.cpp" line="86"/>
        <source>Web UI: HTTPS setup successful</source>
        <translation>Interface Web: HTTPS configurado com sucesso</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="88"/>
        <source>Web UI: HTTPS setup failed, fallback to HTTP</source>
        <translation>Interface Web: falha ao configurar HTTPS, revertendo para HTTP</translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="100"/>
        <source>Web UI: Now listening on IP: %1, port: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webui/webui.cpp" line="103"/>
        <source>Web UI: Unable to bind to IP: %1, port: %2. Reason: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Web UI: Now listening on port %1</source>
        <translation type="obsolete">Web UI: escutando agora a porta %1</translation>
    </message>
    <message>
        <source>Web UI: Unable to bind to port %1. %2</source>
        <translation type="obsolete">Interface Web: Não foi possível vincular à porta %1. %2</translation>
    </message>
</context>
<context>
    <name>about</name>
    <message>
        <location filename="../gui/about_imp.h" line="67"/>
        <source>An advanced BitTorrent client programmed in C++, based on Qt toolkit and libtorrent-rasterbar.</source>
        <translation>Um cliente BitTorrent avançado escrito em C++, baseado no toolkit Qt e libtorrent-rasterbar.</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="68"/>
        <source>Copyright %1 2006-2017 The qBittorrent project</source>
        <translation>Copyright %1 2006-2017 Projeto qBittorrent</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="69"/>
        <source>Home Page:</source>
        <translation>Site:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="70"/>
        <source>Forum:</source>
        <translation>Fórum:</translation>
    </message>
    <message>
        <location filename="../gui/about_imp.h" line="71"/>
        <source>Bug Tracker:</source>
        <translation>Rastreador de bug:</translation>
    </message>
</context>
<context>
    <name>addPeersDialog</name>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="14"/>
        <source>Add Peers</source>
        <translation>Adicionar peers</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="20"/>
        <source>List of peers to add (one IP per line):</source>
        <translation>Lista de peers para adicionar (um IP por linha):</translation>
    </message>
    <message>
        <location filename="../gui/properties/peersadditiondlg.ui" line="37"/>
        <source>Format: IPv4:port / [IPv6]:port</source>
        <translation>Formato: IPv4:porta / [IPv6]:porta</translation>
    </message>
</context>
<context>
    <name>authentication</name>
    <message>
        <location filename="../gui/login.ui" line="14"/>
        <location filename="../gui/login.ui" line="47"/>
        <source>Tracker authentication</source>
        <translation>Autenticação de tracker</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="64"/>
        <source>Tracker:</source>
        <translation>Tracker:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="86"/>
        <source>Login</source>
        <translation>Login</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="94"/>
        <source>Username:</source>
        <translation>Usuário:</translation>
    </message>
    <message>
        <location filename="../gui/login.ui" line="117"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
</context>
<context>
    <name>confirmDeletionDlg</name>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="20"/>
        <source>Deletion confirmation</source>
        <translation>Confirmação de exclusão</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="67"/>
        <source>Remember choice</source>
        <translation>Lembrar escolha</translation>
    </message>
    <message>
        <location filename="../gui/confirmdeletiondlg.ui" line="94"/>
        <source>Also delete the files on the hard disk</source>
        <translation>Deletar também arquivos do disco</translation>
    </message>
</context>
<context>
    <name>confirmShutdownDlg</name>
    <message>
        <location filename="../gui/shutdownconfirmdlg.ui" line="64"/>
        <source>Don&apos;t show again</source>
        <translation>Não exibir novamente</translation>
    </message>
</context>
<context>
    <name>downloadFromURL</name>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="26"/>
        <source>Add torrent links</source>
        <translation>Adicionar links torrent</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="14"/>
        <source>Download from URLs</source>
        <translation>Baixar de URLs</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.ui" line="48"/>
        <source>One link per line (HTTP links, Magnet links and info-hashes are supported)</source>
        <translation>Um link por linha (links HTTP, links magnéticos e info-hashes são suportados)</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="55"/>
        <source>Download</source>
        <translation>Baixar</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="109"/>
        <source>No URL entered</source>
        <translation>Nenhuma URL inserida</translation>
    </message>
    <message>
        <location filename="../gui/downloadfromurldlg.h" line="109"/>
        <source>Please type at least one URL.</source>
        <translation>Por favor digite uma URL.</translation>
    </message>
</context>
<context>
    <name>errorDialog</name>
    <message>
        <location filename="../app/stacktrace_win_dlg.ui" line="14"/>
        <source>Crash info</source>
        <translation>Informação de crash</translation>
    </message>
</context>
<context>
    <name>fsutils</name>
    <message>
        <location filename="../base/private/profile_p.cpp" line="93"/>
        <source>Downloads</source>
        <translation>Downloads</translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <location filename="../base/utils/misc.cpp" line="85"/>
        <source>B</source>
        <comment>bytes</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="86"/>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="87"/>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation>MiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="88"/>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation>GiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="89"/>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation>TiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="90"/>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation>PiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="91"/>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation>EiB</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="283"/>
        <source>Python not detected</source>
        <translation>Python não detectado</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="312"/>
        <source>Python version: %1</source>
        <translation>Versão do Python: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="325"/>
        <source>Normalized Python version: %1</source>
        <translation>Versão normalizada do Python: %1</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="371"/>
        <source>/s</source>
        <comment>per second</comment>
        <translation>/s</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="463"/>
        <source>%1h %2m</source>
        <comment>e.g: 3hours 5minutes</comment>
        <translation>%1h %2m</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="468"/>
        <source>%1d %2h</source>
        <comment>e.g: 2days 10hours</comment>
        <translation>%1d %2h</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="364"/>
        <source>Unknown</source>
        <comment>Unknown (size)</comment>
        <translation>Desconhecido</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="123"/>
        <source>qBittorrent will shutdown the computer now because all downloads are complete.</source>
        <translation>qBIttorrent irá desligar seu computador agora porque os downloads terminaram.</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="454"/>
        <source>&lt; 1m</source>
        <comment>&lt; 1 minute</comment>
        <translation>&lt; 1 minuto</translation>
    </message>
    <message>
        <location filename="../base/utils/misc.cpp" line="458"/>
        <source>%1m</source>
        <comment>e.g: 10minutes</comment>
        <translation>%1m</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="798"/>
        <source>Working</source>
        <translation>Trabalhando</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="796"/>
        <source>Updating...</source>
        <translation>Atualizando...</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="800"/>
        <source>Not working</source>
        <translation>Sem serviço</translation>
    </message>
    <message>
        <location filename="../webui/btjson.cpp" line="794"/>
        <source>Not contacted yet</source>
        <translation>Não contactado ainda</translation>
    </message>
</context>
<context>
    <name>preview</name>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="14"/>
        <source>Preview selection</source>
        <translation>Seleção de pré-visualização</translation>
    </message>
    <message>
        <location filename="../gui/previewselectdialog.ui" line="20"/>
        <source>The following files support previewing, please select one of them:</source>
        <translation>Os arquivos a seguir suportam pré-visualização, por favor selecione um:</translation>
    </message>
</context>
<context>
    <name>trackerLogin</name>
    <message>
        <location filename="../gui/trackerlogin.cpp" line="44"/>
        <source>Log in</source>
        <translation>Logar</translation>
    </message>
</context>
</TS>
